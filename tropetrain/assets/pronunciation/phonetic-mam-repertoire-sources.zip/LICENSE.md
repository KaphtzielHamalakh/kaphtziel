The statement below is preserved verbatim from the former MAM Google spreadsheet,
which became a frozen historical archive on September 12, 2026.
This statement applies equally to the MAM text and its derivative display in `data/`, and to the
MAM Hebrew that `examples/display.json` quotes.
`DATA-LICENSES.md` at the repository root records the terms of this directory's other files,
and no new grant is made here over other source material. So, in the text below, ignore any
references to "in this spreadsheet" (English) or שבגליון הנתונים הזה (Hebrew).

----
License:

"Miqra according to the Masorah" as found in this spreadsheet was prepared by Seth (Avi) Kadish
from materials that he originally developed at Hebrew Wikisource,
with major technical assistance from Erel Segal-Halevi and Benjamin Denckla.
All of the material is available under the CC-BY-SA 4.0 license, which is found at the following link:

[CC-BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)

Attribution:

Attribution in English and all languages other than Hebrew shall be to "Hebrew Wikisource" (or an equivalent translation) with a direct link to the following page:

[Miqra according to the Masorah](https://en.wikisource.org/wiki/User:Dovi/Miqra_according_to_the_Masorah#beginning)

<!-- No non-Dovi equivalent currently exists for this page on en.wikisource.org. -->

----
רשיון:

"מקרא על פי המסורה" שבגליון הנתונים הזה הוכן ע"י אבי קדיש, על בסיס חומר קיים מהפרויקט שכבר הכין באתר ויקיטקסט, ובעזרת תמיכה טכנית מכרעת מאת אראל סגל-הלוי ובנימין דנקלה. כל החומר מוגש תחת הרשיון Creative Commons ייחוס-שיתוף זהה 4.0, שנמצא בקישור הבא:

[ייחוס-שיתוף זהה 4.0](https://creativecommons.org/licenses/by-sa/4.0/deed.he)

ייחוס:

הייחוס בעברית יהיה ל"ויקיטקסט" ביחד עם קישור ישיר לדף שבקישור הבא:

[מקרא על פי המסורה](https://he.wikisource.org/wiki/%D7%9E%D7%A7%D7%A8%D7%90_%D7%A2%D7%9C_%D7%A4%D7%99_%D7%94%D7%9E%D7%A1%D7%95%D7%A8%D7%94#%D7%A8%D7%90%D7%A9)
