"""Original diagnostic: constrained token support is not a reviewed word boundary."""
from pathlib import Path
import hashlib,json,math,time
import numpy as np
from ctc_research import source_projection,viterbi_ctc,sha256
ROOT=Path(__file__).resolve().parent

def edit_distance(a,b):
 row=list(range(len(b)+1))
 for i,x in enumerate(a,1):
  nxt=[i]
  for j,y in enumerate(b,1):nxt.append(min(row[j]+1,nxt[-1]+1,row[j-1]+(x!=y)))
  row=nxt
 return row[-1]

bindings=json.loads((ROOT/'reader-bindings.json').read_text());vocab=json.loads(Path('/private/tmp/tropetrain-align-model-he53/vocab.json').read_text());projection=source_projection(bindings,vocab)
(ROOT/'analysis-projection.json').write_text(json.dumps(projection,ensure_ascii=False,indent=2)+'\n')
summary=[]
for meta_file in sorted(ROOT.glob('*-inference.json')):
 if '-preview-'in meta_file.name:continue
 meta=json.loads(meta_file.read_text());source=meta['record'];path=ROOT/meta['emissionsFile'];assert sha256(path)==meta['emissionsSha256'];probs=np.load(path)['log_probs'];assert len(probs)==meta['frames']
 start=time.monotonic();result=viterbi_ctc(probs,projection['tokens'],vocab['[PAD]']);states=result['states'];argmax=probs.argmax(axis=1);words=[];character_support=[]
 for token_index,token in enumerate(projection['tokens']):
  frames=np.flatnonzero(states==token_index*2+1);assert len(frames)
  lp=probs[frames,token];character_support.append({'firstFrame':int(frames[0]),'lastFrame':int(frames[-1]),'frames':int(len(frames)),'meanTargetPosterior':float(np.exp(lp.mean())),'maxTargetPosterior':float(np.exp(lp.max())),'argmaxSupportFrames':int(np.count_nonzero(argmax[frames]==token))})
 stride=meta['strideSamples'];support=meta['convolutionSupportSamples'];rate=meta['sampleRate'];cuts=[c['firstFrame']for c in meta['chunks'][1:]]
 for word in projection['words']:
  a,z=word['tokenRange'];items=character_support[a:z];first=min(x['firstFrame']for x in items);last=max(x['lastFrame']for x in items)
  seconds_a=(first*stride+(support-stride)/2)/rate;seconds_z=(last*stride+(support+stride)/2)/rate
  assert 0<=seconds_a<seconds_z<=source['analysisDuration']
  words.append({'id':word['id'],'hebrew':word['hebrew'],'modelSupport':{'start':round(seconds_a,6),'end':round(seconds_z,6),'firstFrame':first,'lastFrameInclusive':last,'method':'CTC target-token support bins; not confirmed lexical boundaries.'},'evidence':{'targetLetters':len(items),'lettersWithArgmaxSupport':sum(x['argmaxSupportFrames']>0 for x in items),'meanLetterPosterior':float(np.mean([x['meanTargetPosterior']for x in items])),'weakestLetterMaxPosterior':min(x['maxTargetPosterior']for x in items),'crossesInferenceCoreCut':any(first<=c<=last for c in cuts)},'approvedBoundary':None,'review':None})
 target=projection['projection'];greedy=meta['unconstrainedGreedyText'];no_space_target=target.replace(' ','');no_space_greedy=greedy.replace(' ','');cer=edit_distance(no_space_target,no_space_greedy)/len(no_space_target);wer=edit_distance(target.split(),greedy.split())/len(words)
 rec={'schema':'tropetrain-acoustic-word-support-research-v1','status':'unreviewed-model-proposal','sourceRecordId':source['recordId'],'originalSha256':source['originalSha256'],'analysisSha256':source['analysisSha256'],'readerBindingsSha256':sha256(ROOT/'reader-bindings.json'),'coverage':bindings['coverage'],'model':{'id':meta['model'],'revision':meta['modelRevision'],'weightSha256':meta['modelSha256'],'license':meta['modelLicense']},'clock':{'analysisRate':rate,'analysisDuration':source['analysisDuration'],'strideSamples':stride,'convolutionSupportSamples':support,'frameBinMethod':'Center each convolution frame on its sample support; bin width equals exact stride. No source duration fitting, interpolated gaps or guessed codec offset.','timeOrigin':meta['timeOrigin']},'diagnostics':{'unconstrainedGreedyText':greedy,'analysisOnlyReferenceText':target,'greedyCharacterErrorRateWithoutSpaces':cer,'greedyWordErrorRateAgainstConsonantalProjection':wer,'wordsWithEveryLetterHavingSomeArgmaxSupport':sum(w['evidence']['targetLetters']==w['evidence']['lettersWithArgmaxSupport']for w in words),'wordsWithNoArgmaxSupportedLetters':sum(w['evidence']['lettersWithArgmaxSupport']==0 for w in words),'ctcConstrainedLogProbability':result['logProbability'],'elapsedSeconds':round(time.monotonic()-start,3)},'limits':['Constrained CTC must fit every target token; a finite path does not prove the recording contains every supplied word or source spelling.','A modern speech recognizer makes many errors on chant. These scores are uncalibrated model evidence, not linguistic/cantorial approval.','Support bins often omit consonant onsets or sung vowel tails. Audition with context; do not treat them as complete word/syllable durations.','Marked Hebrew, reader IDs, original audio and pronunciation/melody fields remain unchanged. Source edition comparison, word boundaries, syllable/phoneme timings and independent review remain unassigned.'],'words':words,'timedWords':None,'syllableAlignment':None,'phonemes':None,'musicalNotes':None,'independentReview':None}
 dest=ROOT/(source['recordId']+'-word-support.json');dest.write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');summary.append({'record':source['recordId'],'frames':len(probs),'targetTokens':len(projection['tokens']),'words':len(words),'CER_no_spaces':cer,'WER':wer,'allLettersSomeArgmax':rec['diagnostics']['wordsWithEveryLetterHavingSomeArgmaxSupport'],'noArgmaxLetters':rec['diagnostics']['wordsWithNoArgmaxSupportedLetters'],'firstWords':words[:4],'lastWord':words[-1],'proposalSha256':sha256(dest)})
 print(json.dumps(summary[-1],ensure_ascii=False),flush=True)
(ROOT/'alignment-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
