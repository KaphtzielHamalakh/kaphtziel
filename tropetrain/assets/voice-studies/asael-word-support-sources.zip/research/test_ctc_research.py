import itertools,json,math,unittest
from pathlib import Path
import numpy as np
from ctc_research import viterbi_ctc,source_projection,convolution_clock

def collapse(path,blank):return[k for k,_ in itertools.groupby(path)if k!=blank]
def oracle(probs,target,blank):
 best=-math.inf
 for path in itertools.product(range(probs.shape[1]),repeat=len(probs)):
  if collapse(path,blank)==target:best=max(best,sum(probs[t,k]for t,k in enumerate(path)))
 return best
class ExactCtcTests(unittest.TestCase):
 def test_ctc_path_matches_exhaustive_oracle_for_repeats_blanks_and_both_terminal_states(self):
  rng=np.random.default_rng(620)
  for frames in range(2,6):
   for target in [[1],[2],[1,2],[2,1],[1,1],[2,2]]:
    if frames<len(target)+sum(a==b for a,b in zip(target,target[1:])):continue
    p=rng.random((frames,3));p/=p.sum(axis=1,keepdims=True);p=np.log(p)
    actual=viterbi_ctc(p,target,0)
    self.assertAlmostEqual(actual['logProbability'],oracle(p,target,0),places=10)
    self.assertEqual(collapse(actual['labels'][actual['states']],0),target)
 def test_repeat_cannot_use_one_unbroken_character_without_an_intervening_blank(self):
  p=np.log(np.array([[.01,.99],[.99,.01],[.01,.99]]));r=viterbi_ctc(p,[1,1],0)
  self.assertEqual(r['labels'][r['states']].tolist(),[1,0,1])
  with self.assertRaises(ValueError):viterbi_ctc(p[:2],[1,1],0)
 def test_invalid_inputs_are_refused_without_interpolation_or_unknown_token_invention(self):
  for p,target,blank in [(np.zeros((3,2)),[0],0),(np.zeros((3,2)),[2],0),(np.zeros((3,2)),[],0),(np.array([[float('nan'),0]]),[1],0),(np.zeros((0,2)),[1],0)]:
   with self.assertRaises(ValueError):viterbi_ctc(p,target,blank)
 def test_marked_hebrew_cgj_mappiq_and_maqqef_remain_exact_with_explicit_letter_cluster_ranges(self):
  raw={'words':[{'id':'gen-13-3-13','hebrew':'אֽ͏ָהֳלוֹ֙'},{'id':'test-mappiq','hebrew':'לָהּ־'}]};before=json.dumps(raw,ensure_ascii=False)
  vocab={c:i for i,c in enumerate('אהלויךםןףץ|')};p=source_projection(raw,vocab)
  self.assertEqual(json.dumps(raw,ensure_ascii=False),before);self.assertEqual(p['projection'],'אהלו לה')
  self.assertEqual([w['hebrew']for w in p['words']],[w['hebrew']for w in raw['words']])
  first=p['sourceLetters'][0];self.assertEqual(first['markedHebrew'],'אֽ͏ָ');self.assertEqual(first['range'],[0,4])
  self.assertEqual([x['markedHebrew']for x in p['sourceLetters']if x][-1],'הּ')
  self.assertEqual(p['owners'].count(None),1)
 def test_unsupported_letters_and_empty_source_words_fail_without_rewriting_the_text(self):
  for text in ['abc','־','אA']:
   with self.assertRaises(ValueError):source_projection({'words':[{'id':'one','hebrew':text}]},{'א':1,'|':2})
 def test_complete_original_passage_retains_every_word_id_mark_and_source_letter_range(self):
  root=Path(__file__).resolve().parent;b=json.loads((root/'reader-bindings.json').read_text());v=json.loads(Path('/private/tmp/tropetrain-align-model-he53/vocab.json').read_text());before=json.dumps(b,ensure_ascii=False);p=source_projection(b,v)
  self.assertEqual(len(p['words']),469);self.assertEqual(p['words'][0]['id'],'gen-1-1-1');self.assertEqual(p['words'][-1]['id'],'gen-2-3-16')
  self.assertEqual(p['owners'].count(None),468);self.assertEqual(json.dumps(b,ensure_ascii=False),before)
  self.assertEqual([w['hebrew']for w in b['words']],[w['hebrew']for w in p['words']])
  by_id={w['id']:w['hebrew']for w in b['words']}
  for letter in p['sourceLetters']:
   if letter:
    a,z=letter['range'];self.assertEqual(by_id[letter['wordId']].encode('utf-16-le')[a*2:z*2].decode('utf-16-le'),letter['markedHebrew'])
 def test_pinned_model_frame_clock_uses_exact_stride_and_convolution_support(self):
  c=json.loads(Path('/private/tmp/tropetrain-align-model-he53/config.json').read_text());self.assertEqual(convolution_clock(c),(320,400));self.assertEqual(c['pad_token_id'],30)
if __name__=='__main__':unittest.main(verbosity=2)
