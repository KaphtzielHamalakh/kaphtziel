from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,hashlib,subprocess,zipfile
A=Path(__file__).resolve().parent
S=Path('/private/tmp/tropetrain-v94-worktree/tropetrain')
catalog=json.loads((S/'docs/ASAEL-SOURCE-CATALOG.json').read_text())
pack=S/catalog['sourcePack']['file']
assert hashlib.sha256(pack.read_bytes()).hexdigest()==catalog['sourcePack']['sha256']
with zipfile.ZipFile(pack)as z:
 manifest=json.loads(z.read('manifest.json'))
 for r in manifest['files']:
  b=z.read(r['file']);assert len(b)==r['bytes']and hashlib.sha256(b).hexdigest()==r['sha256']
rows=[r for r in catalog['rows']if r['hostPageId']==2460 and r['section']in [['שני'],['שלישי'],['רביעי'],['חמישי'],['שביעי']]]
assert len(rows)==10
records={r['id']:r for r in catalog['recordings']}
dest=A/'originals';dest.mkdir(exist_ok=True)
def fetch(row):
 r=records[row['recordId']];audio=r['audio'];assert r['license']['id']=='CC-BY-SA-3.0'
 p=dest/(r['id']+'.oga')
 if not p.exists():
  tmp=p.with_suffix('.download')
  subprocess.run(['/usr/bin/curl','--fail','--silent','--show-error','--location','--proto','=https','--proto-redir','=https','--max-time','120','--output',str(tmp),audio['file']],check=True)
  b=tmp.read_bytes();assert len(b)==audio['bytes']and hashlib.sha1(b).hexdigest()==audio['sha1'],r['id'];tmp.rename(p)
 b=p.read_bytes();assert len(b)==audio['bytes']and hashlib.sha1(b).hexdigest()==audio['sha1'],r['id']
 result={'recordId':r['id'],'studyId':r['studyId'],'catalogRow':row,'sourceFileRevision':r['sourceFileRevision'],'sourceUrl':r['sourceUrl'],'originalUrl':audio['file'],'bytes':len(b),'sha1':audio['sha1'],'sha256':hashlib.sha256(b).hexdigest(),'catalogDuration':audio['estimatedDurationSeconds'],'file':str(p),'license':r['license'],'originalBytesVerifiedLocally':True,'coverageReview':None,'wordTimes':None,'phonemes':None,'musicalReview':None}
 print(json.dumps({'verifiedOriginal':r['id'],'bytes':len(b)},ensure_ascii=False),flush=True);return result
with ThreadPoolExecutor(max_workers=2)as pool:out=list(pool.map(fetch,rows))
(A/'verified-originals.json').write_text(json.dumps({'sourceCatalogSha256':hashlib.sha256((S/'docs/ASAEL-SOURCE-CATALOG.json').read_bytes()).hexdigest(),'sourcePackSha256':catalog['sourcePack']['sha256'],'records':out,'newBundledAudio':0,'note':'Exact licensed originals downloaded for verification; playback remains on demand. No audio is modified, synthesized, reviewed or assigned word times.'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'verifiedOriginals':len(out),'originalBytes':sum(r['bytes']for r in out),'newBundledAudio':0}),flush=True)
