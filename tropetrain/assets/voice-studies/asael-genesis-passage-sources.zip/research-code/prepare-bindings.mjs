import {readFileSync,writeFileSync,mkdirSync}from'node:fs';
import {createHash}from'node:crypto';
import {getCorpus}from'/private/tmp/tropetrain-v94-worktree/tropetrain/library.js';
const a=new URL('./',import.meta.url),pins=JSON.parse(readFileSync(new URL('verified-originals.json',a))),c=await getCorpus();
const ranges={'ב,ד-יט':[2,4,2,19],'ב,כ-ד,כא':[2,20,4,21],'ד,כב-ה,יח':[4,22,5,18],'ה,יט-כו':[5,19,5,26],'ה,כה-ו,ח':[5,25,6,8]};
mkdirSync(new URL('research/',a),{recursive:true});
const rows=[];
for(const r of pins.records){const p=ranges[r.catalogRow.passageNote];if(!p)throw Error('No explicit source range mapping');const coverage={bookId:'gen',start:{chapter:p[0],verse:p[1]},end:{chapter:p[2],verse:p[3]}},passage=c.passage([{...coverage,id:'source-research'}]),words=passage.verses.flatMap(v=>v.words).map(w=>({id:w.sourceWordId??w.id,hebrew:w.sourceHebrew}));if(!words.length||words.length>1000)throw Error('Unsupported source passage length');const b=Buffer.from(JSON.stringify({recordId:r.recordId,coverage,status:'catalog-passage-candidate',sourceEditionCompared:false,words},null,2)+'\n'),file='research/'+r.recordId+'-reader-bindings.json';writeFileSync(new URL(file,a),b);rows.push({recordId:r.recordId,coverage,words:words.length,first:words[0],last:words.at(-1),file,bytes:b.length,sha256:createHash('sha256').update(b).digest('hex')});}
writeFileSync(new URL('reader-bindings.json',a),JSON.stringify({records:rows,markedHebrewUnchanged:true,sourcePassageReview:null},null,2)+'\n');console.log(JSON.stringify({originals:rows.length,wordOccurrences:rows.reduce((n,r)=>n+r.words,0),distinctPassages:new Set(rows.map(r=>JSON.stringify(r.coverage))).size}));
