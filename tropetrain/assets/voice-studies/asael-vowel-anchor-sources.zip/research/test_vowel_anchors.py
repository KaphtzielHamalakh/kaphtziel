"""Independent small structural fixtures, without a generated-model oracle."""
import unittest
from vowel_anchors import bracket_source_vowels, raw_vowel_observation, source_vowel_route
import copy


class Brackets(unittest.TestCase):
    def setUp(self):
        self.events = [{'classes': ['B'], 'sourceSegmentIds': ['b']},
                       {'classes': ['R'], 'sourceSegmentIds': ['r']}]
        self.atoms = [{'eventIndex': 0, 'classPart': 0}, {'eventIndex': 1, 'classPart': 0}]
        self.positions = {'b': 0, 'v': 1, 'r': 2}
        self.vowels = [{'sourcePosition': 1, 'sourceRealization': {'text': 'o'}}]

    def call(self, left=0, right=1):
        return bracket_source_vowels(left, right, self.atoms, self.events, self.positions, self.vowels)

    def test_single_vowel_and_unknown_quality(self):
        self.assertEqual(self.call(), (self.vowels[0], None))
        # No observed vowel/expected quality is accepted by this operation.
        self.assertNotIn('phonemes', self.call()[0])

    def test_ambiguous_or_deleted_anchor(self):
        self.assertEqual(self.call(None, 1)[1], 'ambiguous-or-unmatched-anchor')
        self.assertEqual(self.call(0, 2)[1], 'nonadjacent-source-consonant-atoms')

    def test_no_nucleus_or_multiple_nuclei(self):
        self.vowels = []
        self.assertEqual(self.call()[1], 'source-vowel-count-0')
        self.vowels = [{'sourcePosition': 1}, {'sourcePosition': 1.5}]
        self.assertEqual(self.call()[1], 'source-vowel-count-2')

    def test_shared_halves_use_outer_edges_without_duplication(self):
        self.events[0]['sourceSegmentIds'] = ['b1', 'b2']
        self.positions = {'b1': 0, 'v1': 1, 'b2': 2, 'v2': 3, 'r': 4}
        self.vowels = [{'sourcePosition': 1, 'unit': 'left'}, {'sourcePosition': 3, 'unit': 'right'}]
        self.assertEqual(self.call()[0]['unit'], 'right')

    def test_affricate_interior_does_not_manufacture_vowel(self):
        self.events = [{'classes': ['T', 'S'], 'sourceSegmentIds': ['ts']}]
        self.atoms = [{'eventIndex': 0, 'classPart': 0}, {'eventIndex': 0, 'classPart': 1}]
        self.assertEqual(self.call()[1], 'inside-one-source-consonant')

    def test_right_furtive_compound_cannot_give_its_vowel_to_the_left_unit(self):
        self.events[1]['categoryId'] = 'FPP_PATAX_XET'
        self.events[1]['classes'] = ['X']
        self.assertEqual(self.call()[1], 'right-anchor-is-unsplit-furtive-compound')

    def test_left_compound_does_not_hide_an_independent_following_vowel(self):
        self.events[0]['categoryId'] = 'FPP_PATAX_XET'
        self.events[0]['classes'] = ['X']
        self.assertEqual(self.call(), (self.vowels[0], None))


class RawObservations(unittest.TestCase):
    def window(self, text):
        return {'chunkIndex': 0, 'rawModelOutput': text,
                'unicodeCharacterTokenBindings': [{'text': c, 'tokenRange': [i, i + 1]} for i, c in enumerate(text)],
                'unreviewedRelativeTokenClock': [i * .02 for i in range(len(text))],
                'sourceClock': {'sourceOffsetSeconds': 0, 'coreSeconds': [0, 1]}}

    def observation(self, text):
        return raw_vowel_observation(self.window(text), {'window': 0, 'textRange': [0, 1]},
                                     {'window': 0, 'textRange': [len(text) - 1, len(text)]})

    def test_stress_length_spaces_and_multiple_vowels_remain_raw(self):
        value, reason = self.observation('b ˈaː ə r')
        self.assertIsNone(reason)
        self.assertEqual(value['modelText'], ' ˈaː ə ')
        self.assertEqual(value['vowelCharacterCount'], 2)
        self.assertEqual(value['modelCharacterRange'], [1, 8])

    def test_punctuation_unknown_and_no_vowel_are_not_filled(self):
        self.assertEqual(self.observation('ba.ar')[1], 'unsupported-between-symbol')
        self.assertEqual(self.observation('ba?r')[1], 'unsupported-between-symbol')
        self.assertEqual(self.observation('b r')[1], 'no-model-vowel')

    def test_context_edges_and_window_seams_are_withheld(self):
        window = self.window('bar')
        window['sourceClock']['coreSeconds'] = [.03, 1]
        self.assertEqual(raw_vowel_observation(window, {'window': 0, 'textRange': [0, 1]},
                                              {'window': 0, 'textRange': [2, 3]})[1], 'vowel-bin-crosses-retained-core')
        self.assertEqual(raw_vowel_observation(window, {'window': 0, 'textRange': [0, 1]},
                                              {'window': 1, 'textRange': [2, 3]})[1], 'different-model-windows')


class SourceRoutes(unittest.TestCase):
    def source(self):
        return {'categories': [{'id': 'QAMATS_G', 'label': 'Qamats gadol', 'kind': 'vowel'}],
                'groups': [{'rows': [{'styles': {'ashkenazic': [{'units': [{
                    'id': 'unit1', 'readerWordId': 'word1', 'text': 'no', 'sourceStress': True,
                    'sourceSegments': {'variants': [{'sourceHebrew': {'text': 'נָ֣'},
                        'readerRanges': [{'readerWordId': 'word1', 'text': 'נָ֥', 'role': 'written'}],
                        'segments': [{'id': 'v1', 'categoryId': 'QAMATS_G', 'part': 'whole',
                                      'sharedWithUnitId': None, 'readerWordId': 'word1',
                                      'realizations': {'ashkenazic': {'text': 'o', 'ascii': 'o'}}}]}]}}]}]}}]}]}

    def test_source_mark_differences_and_stress_remain_independent(self):
        data = self.source()
        before = copy.deepcopy(data)
        _, vowels = source_vowel_route(data, 'ashkenazic')
        self.assertFalse(vowels[0]['sourceMarkedTextEqualsWrittenRanges'])
        self.assertEqual(vowels[0]['sourceHebrew']['text'], 'נָ֣')
        self.assertEqual(vowels[0]['parentSyllableReaderRanges'][0]['text'], 'נָ֥')
        self.assertTrue(vowels[0]['sourceStress'])
        self.assertIsNone(vowels[0]['individualVowelPointRange'])
        self.assertEqual(data, before)

    def test_alternative_source_route_is_never_chosen(self):
        data = self.source()
        variants = data['groups'][0]['rows'][0]['styles']['ashkenazic'][0]['units'][0]['sourceSegments']['variants']
        variants.append(copy.deepcopy(variants[0]))
        with self.assertRaises(AssertionError):
            source_vowel_route(data, 'ashkenazic')


if __name__ == '__main__':
    unittest.main()
