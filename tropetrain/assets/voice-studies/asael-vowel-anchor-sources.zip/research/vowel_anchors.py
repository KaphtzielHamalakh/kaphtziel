"""Original structural vowel observations. No phone, quantity or time approval."""
import math, unicodedata

VOWELS = set('aeiouyɑɐɒæɔəɚɛɜɝɞɘɤɨɪɵœøɶʉɯʊʌʏ')


def bracket_source_vowels(left, right, atoms, events, positions, vowels):
    """Require two unique adjacent source consonants and exactly one source vowel.

    Source geminates occupy both reciprocal half positions, but are one event.
    The right edge of the left event and left edge of the right event bound
    the search. No deleted consonant, unresolved alignment or second vowel
    may be crossed. Vowel quality is deliberately not part of the decision.
    """
    if left is None or right is None:
        return None, 'ambiguous-or-unmatched-anchor'
    if right != left + 1:
        return None, 'nonadjacent-source-consonant-atoms'
    la, ra = atoms[left], atoms[right]
    if la['eventIndex'] == ra['eventIndex']:
        return None, 'inside-one-source-consonant'
    le, re = events[la['eventIndex']], events[ra['eventIndex']]
    if la['classPart'] != len(le['classes']) - 1 or ra['classPart'] != 0:
        return None, 'inside-compound-consonant'
    # A right furtive-patah compound contains a vowel before its consonant.
    # The raw inter-consonant run can therefore cross two source units.
    # Keep that entire compound intact; do not give its vowel to the left unit.
    if re.get('categoryId', '').startswith('FPP_PATAX_'):
        return None, 'right-anchor-is-unsplit-furtive-compound'
    lo = max(positions[x] for x in le['sourceSegmentIds'])
    hi = min(positions[x] for x in re['sourceSegmentIds'])
    assert lo < hi
    between = [v for v in vowels if lo < v['sourcePosition'] < hi]
    if len(between) != 1:
        return None, 'source-vowel-count-' + str(len(between))
    return between[0], None


def raw_vowel_observation(window, left, right):
    """Keep the complete raw inter-consonant text; never normalize its sounds."""
    if left['window'] != right['window']:
        return None, 'different-model-windows'
    a, b = left['textRange'][1], right['textRange'][0]
    if b <= a:
        return None, 'no-between-text'
    text = window['rawModelOutput'][a:b]
    if not any(c in VOWELS for c in text):
        return None, 'no-model-vowel'
    # Combining marks, stress/quantity marks and spacing are retained exactly.
    # Punctuation and unknown symbols are barriers, not silent deletions.
    if any(c not in VOWELS and c not in 'ˈˌːˑ' and not c.isspace()
           and unicodedata.category(c)[0] != 'M' for c in text):
        return None, 'unsupported-between-symbol'
    bindings = window['unicodeCharacterTokenBindings'][a:b]
    assert ''.join(x['text'] for x in bindings) == text
    clock = window['unreviewedRelativeTokenClock']
    ta = min(x['tokenRange'][0] for x in bindings)
    tb = max(x['tokenRange'][1] for x in bindings)
    points = clock[ta:tb]
    assert points and all(math.isfinite(x) for x in points)
    offset = window['sourceClock']['sourceOffsetSeconds']
    lo, hi = offset + min(points), offset + max(points) + 0.02
    start, end = window['sourceClock']['coreSeconds']
    if lo < start - 1e-7 or hi > end + 1e-7:
        return None, 'vowel-bin-crosses-retained-core'
    return {'modelWindow': window['chunkIndex'],
            'modelCharacterRange': [len(window['rawModelOutput'][:a].encode('utf-16-le')) // 2,
                                    len(window['rawModelOutput'][:b].encode('utf-16-le')) // 2],
            'modelCoordinateUnit': 'UTF-16', 'modelText': text,
            'modelLocationBins': [lo, hi],
            'vowelCharacterCount': sum(c in VOWELS for c in text)}, None


def source_vowel_route(source, style):
    """Exact single-route source units/categories; source text is not IPA."""
    positions, vowels, position = {}, [], 0
    categories = {c['id']: c for c in source['categories']}
    for group in source['groups']:
        assert len(group['rows']) == 1
        cells = group['rows'][0]['styles'][style]
        assert len(cells) == 1
        for unit in cells[0]['units']:
            variants = unit['sourceSegments']['variants']
            assert len(variants) == 1
            variant = variants[0]
            for segment in variant['segments']:
                assert segment['id'] not in positions
                positions[segment['id']] = position
                category = categories[segment['categoryId']]
                if category['kind'] == 'vowel' or (category['kind'] == 'diphthong-part'
                                                 and category['id'] != 'YOD_0DAG_PART2_OF_DIPHTHONG'):
                    assert segment['part'] == 'whole' and segment['sharedWithUnitId'] is None
                    assert segment['readerWordId'] == unit['readerWordId']
                    vowels.append({'sourceSegmentId': segment['id'], 'sourcePosition': position,
                                   'categoryId': category['id'], 'categoryLabel': category['label'],
                                   'categoryKind': category['kind'], 'wordId': segment['readerWordId'],
                                   'sourceUnitId': unit['id'], 'sourceUnitText': unit['text'],
                                   'sourceStress': unit['sourceStress'],
                                   'sourceRealization': segment['realizations'][style],
                                   'sourceHebrew': variant['sourceHebrew'],
                                   'parentSyllableReaderRanges': variant['readerRanges'],
                                   'sourceMarkedTextEqualsWrittenRanges': variant['sourceHebrew']['text'] == ''.join(r['text'] for r in variant['readerRanges'] if r['role'] == 'written'),
                                   'individualVowelPointRange': None, 'phonemes': None,
                                   'audioTimes': None, 'quantity': None, 'review': None})
                position += 1
    return positions, vowels
