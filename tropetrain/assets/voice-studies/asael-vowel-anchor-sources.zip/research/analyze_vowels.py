"""Reuse checked v0.61 model observations; no inference or audio processing."""
from pathlib import Path
from collections import Counter
import argparse, gzip, hashlib, json, zipfile
from consonance import observed_atoms
from vowel_anchors import bracket_source_vowels, raw_vowel_observation, source_vowel_route

ROOT = Path(__file__).resolve().parent
BASE_SHA = 'aa4962eb17c450ac272a819f8ad1462e07aa526d1659e71482a8e2a6724f5002'
CTC_SHA = 'e3657e20729abae95d6499d881ec5663a6f27280346547dd5155b8a157cda59f'
STYLES = ['sephardic', 'ashkenazic']


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def utf16_range(text, pair):
    return [len(text[:n].encode('utf-16-le')) // 2 for n in pair]


def key(window, pair, part):
    return (window, *pair, part)


def anchor_reference(candidate):
    return {k: candidate[k] for k in ['modelWindow', 'modelCharacterRange', 'modelGlyph', 'modelClassPart', 'sourceClassPart', 'sourceWordId']} | {'sourceEventId': candidate['sourceEventCandidates'][0]}


def run(base_pack, ctc_pack, destination):
    assert sha(base_pack.read_bytes()) == BASE_SHA, 'The previous source pack must stay exact.'
    assert sha(ctc_pack.read_bytes()) == CTC_SHA, 'The original CTC source pack must stay exact.'
    destination.mkdir(exist_ok=True, parents=True)
    totals = []
    with zipfile.ZipFile(base_pack) as archive, zipfile.ZipFile(ctc_pack) as ctc_archive:
        manifest = json.loads(archive.read('manifest.json'))
        for item in manifest['files']:
            raw = archive.read(item['file'])
            assert len(raw) == item['bytes'] and sha(raw) == item['sha256'], item['file']
        source = json.loads(archive.read('research/source-pronunciation-bindings.json'))
        index = json.loads(archive.read('research/full-index.json'))
        for record in sorted({x['sourceRecordId'] for x in index['windows']}):
            prior_raw = archive.read('proposals/' + record + '.json')
            prior = json.loads(prior_raw)
            ctc = json.loads(ctc_archive.read('proposals/' + record + '.json'))
            assert ctc['source'] == prior['source']
            supports = {w['id']: w['modelSupport'] for w in ctc['words']}
            windows = [json.loads(archive.read('research/full/' + x['file'])) for x in index['windows'] if x['sourceRecordId'] == record]
            assert [w['chunkIndex'] for w in windows] == list(range(len(windows)))
            observed, seam_gaps, excluded = observed_atoms(windows)
            result = {'format': 'tropetrain-vowel-anchor-observations-v1', 'revision': 1,
                      'status': 'unreviewed-structural-vowel-observations', 'source': prior['source'],
                      'coverage': prior['coverage'], 'analysisClock': prior['analysisClock'],
                      'model': prior['model'],
                      'inferenceRecipeSha256': prior['inferenceRecipeSha256'],
                      'priorConsonantProposalSha256': sha(prior_raw), 'baseSourcePackSha256': BASE_SHA,
                      'orthographicSupportSourcePackSha256': CTC_SHA,
                      'sourceCommit': source['sourceCommit'], 'categoryInputSha256': source['categoryInputSha256'],
                      'comparisonStyles': STYLES, 'studies': {}, 'wordTimes': None,
                      'syllableAlignment': None, 'phonemes': None, 'musicalNotes': None,
                      'independentReview': None, 'newSingingVoice': None,
                      'limits': 'Structural model observations only. Two uniquely bound v0.61 consonant anchors must be adjacent source consonant atoms, with exactly one source vowel category between their outer shared-half edges. A right furtive-patah compound is withheld because the run can cross the left vowel unit and the unsplit compound. The raw inter-consonant model text, spaces, stress and quantity marks stay unchanged. Model vowel quality, quantity, stress, phonemes and boundaries are not approved. Source transcription is not converted to IPA and is not used as a vowel-quality acceptance filter. Multiple source vowels, deleted/ambiguous/clock-disagreeing consonants, punctuation, cross-window/core seams and original word-audition clock disagreement remain withheld. Both MAM styles stay independent of the fixed source recording.'}
            for style in STYLES:
                previous = prior['studies'][style]
                positions, vowels = source_vowel_route(source, style)
                events = [e for word in previous['words'] for e in word['sourceEvents']]
                atoms = [{'eventIndex': i, 'classPart': p} for i, e in enumerate(events) for p, _ in enumerate(e['classes'])]
                atom_index = {(events[a['eventIndex']]['eventId'], a['classPart']): i for i, a in enumerate(atoms)}
                anchors = {}
                for word in previous['words']:
                    for candidate in word['candidateConsonants']:
                        if candidate['letterBindingUnique'] and candidate['sourceClassPart'] is not None:
                            assert len(candidate['sourceEventCandidates']) == 1
                            anchors[key(candidate['modelWindow'], candidate['modelCharacterRange'], candidate['modelClassPart'])] = candidate | {'sourceWordId': word['id']}
                words = {w['id']: {'id': w['id'], 'hebrew': w['hebrew'],
                                   'sourceVowels': [v for v in vowels if v['wordId'] == w['id']],
                                   'candidateVowels': [], 'phonemes': None, 'audioTimes': None,
                                   'syllableTimes': None, 'quantity': None, 'review': None} for w in source['readerWords']}
                withheld = Counter()
                for left, right in zip(observed, observed[1:]):
                    observation, reason = raw_vowel_observation(windows[left['window']], left, right)
                    if reason:
                        withheld[reason] += 1
                        continue
                    lc = anchors.get(key(left['window'], utf16_range(windows[left['window']]['rawModelOutput'], left['textRange']), left['classPart']))
                    rc = anchors.get(key(right['window'], utf16_range(windows[right['window']]['rawModelOutput'], right['textRange']), right['classPart']))
                    li = atom_index[(lc['sourceEventCandidates'][0], lc['sourceClassPart'])] if lc else None
                    ri = atom_index[(rc['sourceEventCandidates'][0], rc['sourceClassPart'])] if rc else None
                    vowel, reason = bracket_source_vowels(li, ri, atoms, events, positions, vowels)
                    if reason:
                        withheld[reason] += 1
                        continue
                    # Independent original CTC audition context, with its unchanged clocks.
                    support = supports[vowel['wordId']]
                    context = [max(0, support['start'] - 1), min(prior['analysisClock']['analysisFrames'] / prior['analysisClock']['analysisRate'], support['end'] + 1)]
                    lo, hi = observation['modelLocationBins']
                    if lo < context[0] - 1e-7 or hi > context[1] + 1e-7:
                        withheld['original-word-audition-clock-disagreement'] += 1
                        continue
                    words[vowel['wordId']]['candidateVowels'].append(observation | {
                        'sourceVowelSegmentId': vowel['sourceSegmentId'], 'sourceUnitId': vowel['sourceUnitId'],
                        'leftAnchor': anchor_reference(lc), 'rightAnchor': anchor_reference(rc),
                        'sourceVowelCountBetweenAnchors': 1, 'uniqueConsonantAnchors': True,
                        'adjacentSourceConsonantAtoms': True, 'withinOriginalWordAuditionContext': True,
                        'crossWordAnchorContext': lc['sourceWordId'] != vowel['wordId'] or rc['sourceWordId'] != vowel['wordId'],
                        'vowelQualityCompared': False, 'phonemes': None, 'audioTimes': None,
                        'quantity': None, 'review': None})
                diagnostics = {'sourceVowelCategories': len(vowels),
                               'sourceSyllablesWithMarkedDifferences': sum(not v['sourceMarkedTextEqualsWrittenRanges'] for v in vowels),
                               'candidateObservations': sum(len(w['candidateVowels']) for w in words.values()),
                               'wordsWithObservations': sum(bool(w['candidateVowels']) for w in words.values()),
                               'sourceSyllablesWithObservations': len({c['sourceUnitId'] for w in words.values() for c in w['candidateVowels']}),
                               'sourceVowelsWithoutObservation': len(vowels) - len({c['sourceVowelSegmentId'] for w in words.values() for c in w['candidateVowels']}),
                               'crossWordAnchorObservations': sum(c['crossWordAnchorContext'] for w in words.values() for c in w['candidateVowels']),
                               'retainedModelVowelCharactersLinked': sum(c['vowelCharacterCount'] for w in words.values() for c in w['candidateVowels']),
                               'withheldOrExcludedInterconsonantCases': dict(sorted(withheld.items())),
                               'priorModelCoreBoundaryConsonantsWithheld': len(seam_gaps),
                               'priorModelContextConsonantAtomsExcluded': excluded}
                result['studies'][style] = {'words': list(words.values()), 'diagnostics': diagnostics}
                totals.append({'record': record, 'style': style, **diagnostics})
                print(json.dumps(totals[-1]), flush=True)
            raw = (json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode()
            (destination / (record + '.json')).write_bytes(raw)
    (destination / 'summary.json').write_text(json.dumps(totals, indent=2) + '\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-pack', type=Path, required=True)
    parser.add_argument('--ctc-pack', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=ROOT / 'proposals')
    args = parser.parse_args()
    run(args.base_pack, args.ctc_pack, args.output)
