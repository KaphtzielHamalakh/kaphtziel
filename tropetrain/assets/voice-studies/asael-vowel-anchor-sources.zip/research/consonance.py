"""Original all-optimal consonant correspondence. No phonetic or timing approval."""
import math,unicodedata

def all_optimal_matches(expected,observed):
 """Every minimum-edit interpretation of each observed atom; no chosen tie-break path."""
 import numpy as np
 if any(not isinstance(x,str)or not x for x in [*expected,*observed]):raise ValueError('Nonempty analysis-class strings required.')
 n,m=len(expected),len(observed);f=np.empty((n+1,m+1),dtype=np.int32);b=np.empty_like(f);f[:,0]=np.arange(n+1);f[0,:]=np.arange(m+1)
 for i in range(1,n+1):
  for j in range(1,m+1):f[i,j]=min(f[i-1,j]+1,f[i,j-1]+1,f[i-1,j-1]+int(expected[i-1]!=observed[j-1]))
 b[:,m]=np.arange(n,-1,-1);b[n,:]=np.arange(m,-1,-1)
 for i in range(n-1,-1,-1):
  for j in range(m-1,-1,-1):b[i,j]=min(b[i+1,j]+1,b[i,j+1]+1,b[i+1,j+1]+int(expected[i]!=observed[j]))
 distance=int(f[n,m]);rows=[]
 for j in range(m):
  candidates=[];unmatched=False
  for i in range(n+1):
   if int(f[i,j])+1+int(b[i,j+1])==distance:unmatched=True
   if i<n and int(f[i,j])+int(expected[i]!=observed[j])+int(b[i+1,j+1])==distance:
    if expected[i]==observed[j]:candidates.append(i)
    else:unmatched=True
  rows.append({'observedIndex':j,'expectedCandidates':candidates,'unmatchedInSomeOptimalPath':unmatched,'uniqueExpectedIndex':candidates[0]if len(candidates)==1 and not unmatched else None})
 return {'distance':distance,'expectedAtoms':n,'observedAtoms':m,'matches':rows,'method':'Unit-cost insertion/deletion/substitution; every minimum-edit path, exact analysis-class matches only. No best-path tie break or confidence threshold. Not phonological/acoustic approval.'}

# Documented source categories, projected only to an abstract consonant comparison.
# This is not a pronunciation grammar: vowel quality, rhotic/velar allophones,
# geminate length, silence and acoustic boundaries are not realized here.
BASE={
 'ALEF_0MAPIQ_CON':'G','ALEF_1MAPIQ':'G','AYIN_0DAG':'G',
 'BET_0DAG':'V','BET_1DAG_QAL':'B','BET_1DAG_XAZAQ':'B',
 'GIMEL_0DAG':'GIMEL','GIMEL_1DAG_QAL':'GIMEL','GIMEL_1DAG_XAZAQ':'GIMEL',
 'DALET_0DAG':'D','DALET_1DAG_QAL':'D','DALET_1DAG_XAZAQ':'D',
 'HE_0MAPIQ_CON':'H','HE_1MAPIQ':'H','VAV_0DAGOSD_CON':'V','VAV_1DAG':'V',
 'ZAYIN_0DAG':'Z','ZAYIN_1DAG':'Z','XET_0DAG':'X','TET_0DAG':'T','TET_1DAG':'T',
 'YOD_0DAG_CON':'J','YOD_1DAG':'J','YOD_0DAG_PART2_OF_DIPHTHONG':'J',
 'KAF_0DAG':'X','KAF_1DAG_QAL':'K','KAF_1DAG_XAZAQ':'K','FKAF_0DAG':'X','FKAF_1DAG_QAL':'K','FKAF_1DAG_XAZAQ':'K',
 'LAMED_0DAG':'L','LAMED_1DAG':'L','MEM_0DAG':'M','MEM_1DAG':'M','FMEM_0DAG':'M',
 'NUN_0DAG':'N','NUN_1DAG':'N','FNUN_0DAG':'N','SAMEKH_0DAG':'S','SAMEKH_1DAG':'S',
 'PE_0DAG':'F','PE_1DAG_QAL':'P','PE_1DAG_XAZAQ':'P','FPE_0DAG':'F','FPE_1DAG_QAL':'P',
 'TSADI_0DAG':'TS','TSADI_1DAG':'TS','FTSADI_0DAG':'TS','QOF_0DAG':'K','QOF_1DAG':'K',
 'RESH_0DAG':'R','RESH_1DAG':'R','TRUESHIN_0DAG':'SH','TRUESHIN_1DAG':'SH','SIN_0DAG':'S','SIN_1DAG':'S',
 'TAV_1DAG_QAL':'T','TAV_1DAG_XAZAQ':'T','FPP_PATAX_XET':'X','FPP_PATAX_AYIN':'G','FPP_PATAX_MAPIQ_HE':'H'}
def source_classes(category,style):
 if style not in ['sephardic','ashkenazic']:raise ValueError('Unknown source text comparison style.')
 cid=category['id']
 if cid=='TAV_0DAG':return ['T'if style=='sephardic'else'S']
 if cid in BASE:return list(BASE[cid])if BASE[cid]=='TS'else[BASE[cid]]
 if category['kind']in ['silent-letter','silent-vowel-sign','vowel','diphthong-part']:return []
 raise ValueError('Unassigned source consonant category: '+cid)

OBS={**{c:c.upper()for c in 'bdfhklmnpstvzj'},'g':'GIMEL','ɡ':'GIMEL','r':'R','ʁ':'R','ɾ':'R','ʀ':'R','x':'X','χ':'X','ʃ':'SH','ʒ':'ZH','ʔ':'G','ʕ':'AYIN','w':'W','ŋ':'NG','ɲ':'NY','θ':'TH','ð':'DH','ɣ':'GH','ʦ':'TS','ʧ':'TSH','ʤ':'DZH'}
VOWELS=set('aeiouyɑɐɒæɔəɚɛɜɝɞɘɤɨɪɵœøɶʉɯʊʌʏ')
def observed_classes(char):
 if len(char)!=1:raise ValueError('One unchanged Unicode character required.')
 if char in OBS:
  value=OBS[char];return list(value)if value=='TS'else[value]
 if char in VOWELS or char in 'ˈˌːˑ' or char.isspace()or unicodedata.category(char)[0]in ['P','M','Z']:return []
 # Unsupported model symbols stay evidence of a mismatch; never guessed or dropped.
 return ['OTHER_U'+format(ord(char),'04X')]

def source_events(data,style):
 words={w['id']:w['hebrew']for w in data['readerWords']};order={w['id']:i for i,w in enumerate(data['readerWords'])};catalog={c['id']:c for c in data['categories']};events=[];seen_words=[]
 for group in data['groups']:
  assert group['readerHebrew']==[words[x]for x in group['readerIds']],'Source marked words changed.'
  assert len(group['rows'])==1,'Multiple source rows require a route graph, never choose a branch.'
  cells=group['rows'][0]['styles'][style];assert len(cells)==1,'Multiple source style columns remain separate.'
  units=cells[0]['units'];records=[]
  for u in units:
   assert len(u['sourceSegments']['variants'])==1,'Multiple source Hebrew alternatives require separate routes.'
   v=u['sourceSegments']['variants'][0];bindings={x['sourceSegmentId']:x for x in v['letterClusterBindings']['bindings']}
   for seg in v['segments']:records.append((seg,u,bindings[seg['id']]))
  handled=set()
  for seg,u,binding in records:
   if seg['id']in handled:continue
   category=catalog[seg['categoryId']];classes=source_classes(category,style)
   if not classes:continue
   members=[(seg,u,binding)]
   if seg['part']!='whole':
    other=[r for r in records if r[0]['categoryId']==seg['categoryId']and r[1]['id']==seg['sharedWithUnitId']and r[0]['sharedWithUnitId']==u['id']and r[0]['part']!=seg['part']]
    assert len(other)==1 and {seg['part'],other[0][0]['part']}=={'first-half-shared','second-half-shared'},'Missing reciprocal shared half.';members+=other
   owners={m[0]['readerWordId']for m in members};assert len(owners)==1 and None not in owners,'Shared word ownership remains unresolved.';owner=next(iter(owners));assert owner in words
   event={'eventId':'+'.join(m[0]['id']for m in members),'wordId':owner,'hebrew':words[owner],'categoryId':category['id'],'categoryLabel':category['label'],'sourceSegmentIds':[m[0]['id']for m in members],'sourceUnitIds':[m[1]['id']for m in members],'sourceClusters':[m[2]for m in members],'classes':classes,'quantity':None,'phonemes':None,'audioTimes':None,'review':None}
   for m in members:handled.add(m[0]['id'])
   events.append(event)
  seen_words+=group['readerIds']
 assert seen_words==[w['id']for w in data['readerWords']],'Source word sequence changed.'
 assert all(order[a['wordId']]<=order[b['wordId']]for a,b in zip(events,events[1:]))
 return events

def observed_atoms(windows):
 atoms=[];withheld=[];context_excluded=0
 for window in windows:
  if not window['tokenClockValidInInput']:raise ValueError('Invalid unreviewed model clock; preserve raw observation separately.')
  raw=window['rawModelOutput'];clock=window['unreviewedRelativeTokenClock'];offset=window['sourceClock']['sourceOffsetSeconds'];start,end=window['sourceClock']['coreSeconds'];bindings=window['unicodeCharacterTokenBindings'];assert ''.join(b['text']for b in bindings)==raw
  for binding in bindings:
   a,b=binding['textRange'];assert raw[a:b]==binding['text'];classes=observed_classes(binding['text'])
   if not classes:continue
   ta,tb=binding['tokenRange'];points=clock[ta:tb];assert points and all(math.isfinite(p)for p in points)
   lo=offset+min(points);hi=offset+max(points)+0.02
   record={'window':window['chunkIndex'],'textRange':[a,b],'text':binding['text'],'tokenRange':[ta,tb],'modelLocationBins':[lo,hi],'wordTimes':None,'phonemes':None,'review':None}
   if hi<=start+1e-7 or lo>=end-1e-7:
    context_excluded+=len(classes);continue
   if lo<start-1e-7 or hi>end+1e-7:
    withheld.append({**record,'reason':'token-bin-crosses-retained-core'});continue
   for part,c in enumerate(classes):atoms.append({**record,'class':c,'classPart':part})
 return atoms,withheld,context_excluded
