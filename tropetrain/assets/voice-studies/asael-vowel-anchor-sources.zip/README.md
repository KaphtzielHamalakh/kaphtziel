# Conditional source-vowel observations

Genesis 1:1–2:3, two unchanged Asael performances and 469 unchanged marked Hebrew words. These are unreviewed speech-model observations linked structurally through uniquely matched consonants to one exact source vowel category and its original syllable. No vowel quality, quantity, stress, phoneme, word/syllable/note time or singing voice is approved. Source Latin transcription is not converted to IPA. Raw model spaces/stress/quantity/errors remain unchanged. Multiple source vowels, ambiguous/deleted consonant anchors, punctuation and clock/seam disagreements are withheld. Source syllables, source stress and reciprocal shared consonants remain exact. Cross-word anchors are labeled; model spaces never determine Hebrew ownership.

All1120original source syllable units per style remain represented:1106units have a separate vowel category;14furtive-patah-plus-guttural compound units remain intact as unresolved rows, with no separate vowel observation, phoneme or time. Their original source kind is vowel-consonant-pair. A model run ending at a right furtive-patah compound is withheld because it can cross the left vowel unit and the compound's vowel; no compound vowel is given to the preceding unit. source-unit-inventory.json retains their complete original marked ranges, transcription, stress and source-category identity. Source and reader mark differences are kept separately. vowel_source_inventory.py recomputes this inventory from the pinned original source bindings.

The two earlier, unchanged archives provide all original raw model observations, source word/syllable/category bindings, inference recipes, environments, source/model hashes, licenses and original CTC supports:

* https://kaphtziel.com/tropetrain/assets/voice-studies/asael-phonetic-word-sources.zip — SHA256 aa4962eb17c450ac272a819f8ad1462e07aa526d1659e71482a8e2a6724f5002
* https://kaphtziel.com/tropetrain/assets/voice-studies/asael-word-support-sources.zip — SHA256 e3657e20729abae95d6499d881ec5663a6f27280346547dd5155b8a157cda59f

Reproduce from this archive's research directory, using Python3 standard library only:

python3 analyze_vowels.py --base-pack /path/asael-phonetic-word-sources.zip --ctc-pack /path/asael-word-support-sources.zip --output /path/rebuilt-proposals
python3 -m unittest -v test_vowel_anchors.py

No audio decoding, new inference, model download, time scaling or threshold tuning occurs. The app build checks all archive file hashes and independently recomputes the two complete proposals from the pinned dependency archives. No model weights or extra audio are included. The successful v0.61 inference is not repeated.

Asael originals: CC BY-SA3.0, https://creativecommons.org/licenses/by-sa/3.0/ . Miqra according to the Masorah / Phonetic MAM by Benjamin Denckla, with Seth (Avi) Kadish and Erel Segal-Halevi: CC BY-SA4.0, https://creativecommons.org/licenses/by-sa/4.0/ . Their full existing notices and prior computation-source attribution remain unchanged. Model notmax123/whisper-heb-ipa revision6f7c493615d163a99ed6ea09b2cb7241760d868b: Apache2.0 explicit pinned card in prior archive; full Apache license included here. Original new research code: CC0 https://creativecommons.org/publicdomain/zero/1.0/ . Research derived from the cited material retains its source attribution and applicable share-alike terms. This archive does not assert new rights over source performances or authorize a historical synthesized voice.
