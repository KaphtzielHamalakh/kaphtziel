"""Analyze unchanged licensed originals, without sound output or approved timing."""
from pathlib import Path
import json,hashlib,math,importlib.util,shutil,sys
A=Path(__file__).resolve().parent;R=A/'research';R.mkdir(exist_ok=True)
OLD=A.parent/'acoustic-alignment-0.60'
spec=importlib.util.spec_from_file_location('source_preserving_ctc',OLD/'ctc_research.py');ctc=importlib.util.module_from_spec(spec);spec.loader.exec_module(ctc)
ctc.ROOT=R
shutil.copy2(OLD/'model-files.json',R/'model-files.json')
shutil.copy2(OLD/'ctc_research.py',R/'ctc_research-source.py')
shutil.copy2(OLD/'model-card.md',R/'model-card.md')
import numpy as np
import scipy
from scipy.signal import resample_poly
import soundfile as sf
pins=json.loads((A/'verified-originals.json').read_text());records=[]
for r in pins['records']:
 p=Path(r['file']);assert ctc.sha256(p)==r['sha256']
 signal,rate=sf.read(p,dtype='float32',always_2d=True);assert signal.shape[1]==1 and rate>0 and np.isfinite(signal).all()
 divisor=math.gcd(rate,16000);converted=resample_poly(signal[:,0],16000//divisor,rate//divisor,window=('kaiser',5.0),padtype='constant').astype(np.float32)
 assert len(converted)==math.ceil(len(signal)*16000/rate)and np.isfinite(converted).all()
 target=R/(r['recordId']+'-analysis.wav');sf.write(target,converted,16000,subtype='FLOAT');assert ctc.sha256(p)==r['sha256']
 records.append({'recordId':r['recordId'],'originalFile':str(p),'originalSha256':r['sha256'],'analysisFile':str(target),'analysisSha256':ctc.sha256(target),'originalDecodedFrames':len(signal),'originalRate':rate,'originalDecodedDuration':len(signal)/rate,'catalogDuration':r['catalogDuration'],'analysisFrames':len(converted),'analysisRate':16000,'analysisDuration':len(converted)/16000,'decoder':'soundfile '+sf.__version__+', libsndfile '+sf.__libsndfile_version__,'resampler':'scipy '+scipy.__version__+' resample_poly; Kaiser5, constant padding, untrimmed origin; no source mutation or time scaling','wordTimes':None,'review':None})
 print(json.dumps({'decoded':r['recordId'],'duration':len(signal)/rate,'catalogDuration':r['catalogDuration']}),flush=True)
(R/'source-audio.json').write_text(json.dumps(records,indent=2)+'\n')
# The existing pinned, independently tested exact CTC implementation remains unchanged.
# Load one verified model, infer every new original, never synthesize speech or sound.
ctc.inference()
