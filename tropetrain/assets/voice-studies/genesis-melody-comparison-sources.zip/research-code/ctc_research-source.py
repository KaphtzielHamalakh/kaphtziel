"""Original source-preserving CTC research; no reviewed timings or sound generation."""
from pathlib import Path
import argparse
import hashlib
import itertools
import json
import math
import os
import time
import unicodedata

ROOT = Path(__file__).resolve().parent
MODEL = Path('/private/tmp/tropetrain-align-model-he53')
RATE = 16000


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def source_projection(bindings, vocabulary):
    tokens, owners, source_letters, words = [], [], [], []
    for index, word in enumerate(bindings['words']):
        original = word['hebrew']
        start = len(tokens)
        for offset, char in enumerate(original):
            if not unicodedata.category(char).startswith('L'):
                continue
            if not '\u05d0' <= char <= '\u05ea' or char not in vocabulary:
                raise ValueError('Unsupported source letter; never replace it with an inferred sound: ' + repr(char))
            tokens.append(vocabulary[char])
            owners.append(index)
            utf16 = len(original[:offset].encode('utf-16-le')) // 2
            end = offset + 1
            while end < len(original) and unicodedata.category(original[end]) in ['Mn', 'Mc', 'Me', 'Cf']:
                end += 1
            marked_end = len(original[:end].encode('utf-16-le')) // 2
            source_letters.append({'wordId': word['id'], 'char': char, 'baseRange': [utf16, utf16 + 1],
                                   'range': [utf16, marked_end], 'markedHebrew': original[offset:end]})
        if len(tokens) == start:
            raise ValueError('A source word has no supported letters: ' + word['id'])
        words.append({'id': word['id'], 'hebrew': original, 'tokenRange': [start, len(tokens)]})
        if index < len(bindings['words']) - 1:
            tokens.append(vocabulary['|'])
            owners.append(None)
            source_letters.append(None)
    return {'tokens': tokens, 'owners': owners, 'sourceLetters': source_letters, 'words': words,
            'projection': ''.join(x['char'] if x else ' ' for x in source_letters),
            'method': 'Analysis-only original Hebrew consonants and explicit model word separators. Source words, marks and IDs are copied unchanged. No spelling modernization or pronunciation substitution.'}


def viterbi_ctc(log_probs, target, blank):
    """Maximum-probability exact CTC path; standard blank/label/repeat transitions."""
    import numpy as np
    probs = np.asarray(log_probs)
    target = np.asarray(target, dtype=np.int64)
    if probs.ndim != 2 or not len(target) or not len(probs):
        raise ValueError('Finite emissions and a nonempty target are required.')
    if not np.isfinite(probs).all() or blank < 0 or blank >= probs.shape[1]:
        raise ValueError('Invalid model probabilities or blank label.')
    if (target < 0).any() or (target >= probs.shape[1]).any() or (target == blank).any():
        raise ValueError('Target labels must exist and must not be blank.')
    minimum = len(target) + int(np.count_nonzero(target[1:] == target[:-1]))
    if len(probs) < minimum:
        raise ValueError('Too few frames for this exact transcript; no times are interpolated.')
    labels = np.full(2 * len(target) + 1, blank, dtype=np.int64)
    labels[1::2] = target
    can_skip = np.zeros(len(labels), dtype=bool)
    can_skip[2:] = (labels[2:] != blank) & (labels[2:] != labels[:-2])
    previous = np.full(len(labels), -np.inf, dtype=np.float64)
    previous[0] = probs[0, blank]
    previous[1] = probs[0, target[0]]
    trace = np.zeros((len(probs), len(labels)), dtype=np.uint8)
    for frame in range(1, len(probs)):
        stay = previous
        advance = np.r_[-np.inf, previous[:-1]]
        skip = np.r_[-np.inf, -np.inf, previous[:-2]]
        skip[~can_skip] = -np.inf
        choices = np.stack([stay, advance, skip])
        step = np.argmax(choices, axis=0)
        trace[frame] = step
        previous = choices[step, np.arange(len(labels))] + probs[frame, labels]
    state = len(labels) - 1 if previous[-1] >= previous[-2] else len(labels) - 2
    score = float(previous[state])
    if not math.isfinite(score):
        raise ValueError('No complete CTC path exists; no times are interpolated.')
    path = np.empty(len(probs), dtype=np.int32)
    for frame in range(len(probs) - 1, -1, -1):
        path[frame] = state
        if frame:
            state -= int(trace[frame, state])
    collapsed = [int(k) for k, _ in itertools.groupby(labels[path]) if k != blank]
    assert collapsed == target.tolist()
    return {'states': path, 'labels': labels, 'logProbability': score}


def convolution_clock(config):
    stride, support = 1, 1
    for kernel, step in zip(config['conv_kernel'], config['conv_stride']):
        support += (kernel - 1) * stride
        stride *= step
    return stride, support


def convert_sources():
    import numpy as np
    import scipy
    from scipy.signal import resample_poly
    import soundfile as sf
    repo = ROOT.parents[2] / 'work/kaphtziel-repertoire/tropetrain'
    evidence = json.loads((repo / 'docs/ASAEL-PAIRED-CHANT.json').read_text())
    target = Path('/private/tmp/tropetrain-align-source')
    target.mkdir(exist_ok=True)
    records = []
    for source in evidence['recordings']:
        original = Path('/private/tmp/tropetrain-v59-release-source/tropetrain') / source['audio']['file']
        assert sha256(original) == source['audio']['sha256']
        signal, rate = sf.read(original, dtype='float32', always_2d=True)
        assert signal.shape[1] == 1 and rate == 44100
        divisor = math.gcd(rate, RATE)
        converted = resample_poly(signal[:, 0], RATE // divisor, rate // divisor,
                                  window=('kaiser', 5.0), padtype='constant').astype(np.float32)
        assert len(converted) == math.ceil(len(signal) * RATE / rate)
        output = target / (source['id'] + '.wav')
        sf.write(output, converted, RATE, subtype='FLOAT')
        assert sha256(original) == source['audio']['sha256']
        records.append({'recordId': source['id'], 'originalFile': str(original),
                        'originalSha256': source['audio']['sha256'], 'analysisFile': str(output),
                        'analysisSha256': sha256(output), 'originalDecodedFrames': len(signal),
                        'originalRate': rate, 'originalDecodedDuration': len(signal) / rate,
                        'analysisFrames': len(converted), 'analysisRate': RATE,
                        'analysisDuration': len(converted) / RATE,
                        'decoder': 'soundfile ' + sf.__version__ + ', libsndfile ' + sf.__libsndfile_version__,
                        'resampler': 'scipy ' + scipy.__version__ + ' resample_poly, up160/down441, Kaiser5, zero padding; source start retained. No trimming, time scaling or source mutation.',
                        'wordTimes': None, 'review': None})
    (ROOT / 'source-audio.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(records), flush=True)


def inference(seconds=None):
    script = Path(__file__).read_bytes()
    script_sha = hashlib.sha256(script).hexdigest()
    snapshots = ROOT / 'code-snapshots'
    snapshots.mkdir(exist_ok=True)
    snapshot = snapshots / (script_sha + '.py')
    if snapshot.exists():
        assert snapshot.read_bytes() == script
    else:
        snapshot.write_bytes(script)
    try:
        os.nice(10)
        priority = 'reduced by10'
    except PermissionError:
        priority = 'unchanged; sandbox rejected optional priority adjustment'
    import numpy as np
    import soundfile as sf
    import torch
    import transformers
    from transformers import Wav2Vec2FeatureExtractor, Wav2Vec2ForCTC
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.manual_seed(0)
    torch.use_deterministic_algorithms(True)
    pins = json.loads((ROOT / 'model-files.json').read_text())
    for item in pins['files']:
        assert sha256(MODEL / item['file']) == item['sha256'], item['file']
    config = json.loads((MODEL / 'config.json').read_text())
    vocab = json.loads((MODEL / 'vocab.json').read_text())
    labels = {v: k for k, v in vocab.items()}
    stride, support = convolution_clock(config)
    assert stride == 320 and support == 400 and config['pad_token_id'] == vocab['[PAD]']
    feature = Wav2Vec2FeatureExtractor.from_pretrained(MODEL, local_files_only=True)
    model, info = Wav2Vec2ForCTC.from_pretrained(MODEL, local_files_only=True, use_safetensors=True,
                                              attn_implementation='eager', output_loading_info=True)
    assert not any(info.get(k) for k in ['missing_keys', 'unexpected_keys', 'mismatched_keys', 'error_msgs']), info
    model.eval().to('cpu')
    print('Verified model loaded on CPU, one thread; no audio device.', flush=True)
    for record in json.loads((ROOT / 'source-audio.json').read_text()):
        assert sha256(record['analysisFile']) == record['analysisSha256']
        raw, rate = sf.read(record['analysisFile'], dtype='float32')
        assert rate == RATE
        tensor = feature(raw, sampling_rate=RATE, return_tensors='pt', return_attention_mask=False).input_values
        frames = (len(raw) - support) // stride + 1
        stop = frames if seconds is None else min(frames, int(seconds * RATE / stride))
        emissions, chunks = [], []
        begin_time = time.monotonic()
        for first in range(0, stop, 750):
            last = min(first + 750, stop)
            a, b = max(0, first - 100), min(frames, last + 100)
            start, end = a * stride, (b - 1) * stride + support
            with torch.inference_mode():
                logits = model(tensor[:, start:end]).logits[0]
                assert logits.shape == (b - a, config['vocab_size'])
                selected = torch.log_softmax(logits[first - a:last - a], dim=-1).numpy()
            emissions.append(selected)
            chunks.append({'firstFrame': first, 'lastFrameExclusive': last,
                           'inputSamples': [start, end], 'contextFrames': 100})
            print(json.dumps({'record': record['recordId'], 'retainedFrames': last, 'totalFrames': stop,
                              'elapsedSeconds': round(time.monotonic() - begin_time, 2)}), flush=True)
        matrix = np.concatenate(emissions)
        assert matrix.shape == (stop, len(labels)) and np.isfinite(matrix).all()
        suffix = '-preview' if seconds is not None else ''
        destination = ROOT / (record['recordId'] + suffix + '-emissions.npz')
        np.savez_compressed(destination, log_probs=matrix)
        argmax = matrix.argmax(axis=1)
        greedy = ''.join(labels[int(k)] for k, _ in itertools.groupby(argmax)
                         if k != config['pad_token_id']).replace('|', ' ')
        result = {'schema': 'tropetrain-ctc-emissions-v1', 'record': record,
                  'generatorScriptSha256': script_sha, 'generatorSnapshot': str(snapshot.relative_to(ROOT)),
                  'model': pins['model'], 'modelRevision': pins['revision'],
                  'modelSha256': next(p['sha256'] for p in pins['files'] if p['file'] == 'model.safetensors'),
                  'modelLicense': pins['license'], 'libraries': {'torch': torch.__version__, 'transformers': transformers.__version__},
                  'device': 'cpu', 'threads': 1, 'processPriority': priority, 'soundOutput': False, 'strideSamples': stride,
                  'convolutionSupportSamples': support, 'sampleRate': RATE, 'frames': stop,
                  'timeOrigin': 'Untrimmed decoded/resampled source start. No duration stretching; exact convolution frame grid.',
                  'chunks': chunks, 'normalization': 'Feature extractor normalizes the complete decoded waveform once, before chunking.',
                  'emissionsFile': destination.name, 'emissionsSha256': sha256(destination),
                  'unconstrainedGreedyText': greedy, 'review': None, 'wordTimes': None}
        (ROOT / (record['recordId'] + suffix + '-inference.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
        print(json.dumps({'record': record['recordId'], 'greedyPreview': greedy[:1200],
                          'elapsedSeconds': round(time.monotonic() - begin_time, 2)}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['convert', 'infer'])
    parser.add_argument('--seconds', type=float)
    args = parser.parse_args()
    convert_sources() if args.action == 'convert' else inference(args.seconds)
