"""Source-specific CTC support proposals; never approved word or syllable timing."""
from pathlib import Path
import json,math,time,hashlib,importlib.util
import numpy as np
A=Path(__file__).resolve().parent;R=A/'research';OLD=A.parent/'acoustic-alignment-0.60'
spec=importlib.util.spec_from_file_location('exact_ctc',OLD/'ctc_research.py');ctc=importlib.util.module_from_spec(spec);spec.loader.exec_module(ctc)
pins={r['recordId']:r for r in json.loads((A/'verified-originals.json').read_text())['records']}
bindings={r['recordId']:r for r in json.loads((A/'reader-bindings.json').read_text())['records']}
vocab=json.loads(Path('/private/tmp/tropetrain-align-model-he53/vocab.json').read_text())
def edit(a,b):
 row=list(range(len(b)+1))
 for i,x in enumerate(a,1):
  new=[i]
  for j,y in enumerate(b,1):new.append(min(row[j]+1,new[-1]+1,row[j-1]+(x!=y)))
  row=new
 return row[-1]
summary=[]
for rid,pin in pins.items():
 start=time.monotonic();binding_path=A/bindings[rid]['file'];raw=json.loads(binding_path.read_text());projection=ctc.source_projection(raw,vocab)
 (R/(rid+'-projection.json')).write_text(json.dumps(projection,ensure_ascii=False,indent=2)+'\n')
 meta=json.loads((R/(rid+'-inference.json')).read_text());source=meta['record'];assert source['originalSha256']==pin['sha256']
 path=R/meta['emissionsFile'];assert ctc.sha256(path)==meta['emissionsSha256'];probs=np.load(path)['log_probs'];assert len(probs)==meta['frames']
 result=ctc.viterbi_ctc(probs,projection['tokens'],vocab['[PAD]']);states=result['states'];argmax=probs.argmax(axis=1);support=[]
 for i,token in enumerate(projection['tokens']):
  frames=np.flatnonzero(states==i*2+1);assert len(frames);lp=probs[frames,token]
  support.append({'first':int(frames[0]),'last':int(frames[-1]),'mean':float(np.exp(lp.mean())),'max':float(np.exp(lp.max())),'direct':bool(np.any(argmax[frames]==token))})
 stride=meta['strideSamples'];width=meta['convolutionSupportSamples'];rate=meta['sampleRate'];cuts=[c['firstFrame']for c in meta['chunks'][1:]];words=[]
 for w in projection['words']:
  a,z=w['tokenRange'];s=support[a:z];first=min(x['first']for x in s);last=max(x['last']for x in s);begin=(first*stride+(width-stride)/2)/rate;end=(last*stride+(width+stride)/2)/rate
  assert 0<=begin<end<=source['originalDecodedDuration']
  words.append({'id':w['id'],'hebrew':w['hebrew'],'modelSupport':{'start':round(begin,6),'end':round(end,6),'firstFrame':first,'lastFrameInclusive':last,'method':'CTC target-token support bins; not confirmed lexical boundaries.'},'evidence':{'targetLetters':len(s),'lettersWithArgmaxSupport':sum(x['direct']for x in s),'meanLetterPosterior':float(np.mean([x['mean']for x in s])),'weakestLetterMaxPosterior':min(x['max']for x in s),'crossesInferenceCoreCut':any(first<=c<=last for c in cuts)},'approvedBoundary':None,'review':None})
 target=projection['projection'];greedy=meta['unconstrainedGreedyText'];cer=edit(target.replace(' ',''),greedy.replace(' ',''))/len(target.replace(' ',''));wer=edit(target.split(),greedy.split())/len(words)
 diagnostics={'unconstrainedGreedyText':greedy,'analysisOnlyReferenceText':target,'greedyCharacterErrorRateWithoutSpaces':cer,'greedyWordErrorRateAgainstConsonantalProjection':wer,'wordsWithEveryLetterHavingSomeArgmaxSupport':sum(w['evidence']['targetLetters']==w['evidence']['lettersWithArgmaxSupport']for w in words),'wordsWithNoArgmaxSupportedLetters':sum(w['evidence']['lettersWithArgmaxSupport']==0 for w in words),'ctcConstrainedLogProbability':result['logProbability']}
 value={'format':'tropetrain-word-support-v1','status':'unreviewed-model-support','source':{'id':rid,'bytes':pin['bytes'],'sha1':pin['sha1'],'sha256':pin['sha256'],'duration':source['originalDecodedDuration']},'coverage':raw['coverage'],'sourcePassageStatus':'catalog-candidate-not-content-reviewed','sourceEditionCompared':False,'model':{'id':meta['model'],'revision':meta['modelRevision'],'weightSha256':meta['modelSha256'],'license':'Apache-2.0'},'clock':{'analysisRate':rate,'analysisDuration':source['analysisDuration'],'strideSamples':stride,'convolutionSupportSamples':width,'frameBinMethod':'Exact convolution-centered bins; no invented durations, offsets or interpolated gaps.','timeOrigin':meta['timeOrigin']},'diagnostics':diagnostics,'inputs':{'readerBindingsSha256':ctc.sha256(binding_path),'analysisSha256':source['analysisSha256'],'emissionsSha256':meta['emissionsSha256'],'inferenceSourceSha256':meta['generatorScriptSha256'],'analysisGeneratorSha256':ctc.sha256(__file__)},'limits':['The primary catalog states this candidate range; source audio content and edition correspondence remain unreviewed.','Constrained CTC must fit every target token; a finite path does not prove that every supplied word occurs in the recording.','A modern speech recognizer makes substantial errors on chant; scores are uncalibrated, not musical or linguistic approval.','Support bins may omit onsets and sustained tails. Audition with context and enter heard boundaries yourself; no draft is filled.','Original recordings, marked Hebrew, IDs, source melody and pronunciation labels are unchanged. No voice or phonetic realization is synthesized.'],'words':words,'timedWords':None,'syllableAlignment':None,'phonemes':None,'musicalNotes':None,'independentReview':None}
 out=R/(rid+'-word-support.json');out.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');summary.append({'recordId':rid,'words':len(words),'coverage':raw['coverage'],'CER':cer,'WER':wer,'allDirect':diagnostics['wordsWithEveryLetterHavingSomeArgmaxSupport'],'noDirect':diagnostics['wordsWithNoArgmaxSupportedLetters'],'first':words[0]['hebrew'],'last':words[-1]['hebrew'],'greedyEnding':greedy[-250:],'proposalSha256':ctc.sha256(out),'seconds':round(time.monotonic()-start,2)})
 print(json.dumps(summary[-1],ensure_ascii=False),flush=True)
(A/'alignment-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
