"""Source-only, sparse agreement cues; never infer word extents or approval."""
from pathlib import Path
import os,json,hashlib,re,bisect,math
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
try:os.nice(10)
except PermissionError:pass
import numpy as np,soundfile as sf
from transformers import WhisperTokenizer
A=Path(__file__).resolve().parent;P=A.parent/'torah-gap-word-support-0.100';C=Path('/private/tmp/tropetrain-cantillation-turbo-38885a17');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text());rules=read(A/'predeclared-anchor-rules.json')
ctc_path=P/'alternate-research/asael-catalog-183403-30/unprompted-greedy.json';wh_path=P/'model-research/benchmark/alternate-toldot-last30.json';bind_path=P/'alternate-research/asael-catalog-183403-30/reader-bindings.json';ctc=read(ctc_path);wh=read(wh_path);bindings=read(bind_path);sources=read(P/'alternate-research/source-audio.json');src=sources[0];identity=wh['identity'];assert ctc['complete'] and wh['complete'] and ctc['sourceOriginalSha256']==identity['sourceOriginalSha256']==src['originalSha256'];assert ctc['analysisSha256']==identity['analysisSha256']==src['analysisSha256'];assert ctc['expectedTranscript']is None and ctc['recognitionPrompt']is None and ctc['languageModel']is None and wh['expectedTranscript']is None and wh['recognitionPrompt']is None and wh['knownPassageSentToDecoder']is False;assert not wh['hitGenerationLengthCap'];assert sha(src['originalFile'])==src['originalSha256'] and sha(src['analysisFile'])==src['analysisSha256']
model=read(P/'model-research/model-files.json');assert model['revision']==identity['modelRevision'] and model['license']=='MIT'
for item in model['files']:
 if item['file']!='model.safetensors':assert sha(C/item['file'])==item['sha256']
reader_path=Path('/private/tmp/tropetrain-v100-torah-search.json');assert sha(reader_path)==read(P/'domain-benchmark-quality.json')['readerWordFileSha256'];words=read(reader_path);assert len(words)==79985;letters=lambda s:''.join(re.findall('[א-ת]',s));flat='';spans=[];prev=None
for w in words:
 if prev is not None and prev!=w['bookId']:flat+='\0'
 start=len(flat);flat+=letters(w['hebrew']);spans.append((start,len(flat)));prev=w['bookId']
starts=[s[0]for s in spans];ends=[s[1]for s in spans];ng={};k=rules['wholeTorahUniqueContextLetters']
for i in range(len(flat)-k+1):
 s=flat[i:i+k]
 if '\0'in s:continue
 ng[s]=i if s not in ng else -1
canonical={w['id']:w for w in words}
for w in bindings['words']:assert canonical[w['id']]['hebrew']==w['hebrew']
# Decode standard tokenizer data only. Each raw Unicode character retains the
# clocks of its original UTF8 bytes, including byte-split base vocabulary tokens.
tok=WhisperTokenizer.from_pretrained(C,local_files_only=True);raw=bytearray();byte_clocks=[];byte_tokens=[]
for token,time in zip(wh['tokenIds'],wh['modelTokenTimestampsWithinClip']):
 if token in tok.all_special_ids:continue
 if token in tok.added_tokens_decoder:b=tok.added_tokens_decoder[token].content.encode('utf8')
 else:b=bytes(tok.byte_decoder[c]for c in tok.convert_ids_to_tokens(token))
 raw.extend(b);byte_clocks.extend([time]*len(b));byte_tokens.extend([token]*len(b))
text=raw.decode('utf8');assert text==wh['rawModelText'];wh_chars=[];offset=0;base=identity['sourceAnalysisSampleRange'][0]/16000
for c in text:
 n=len(c.encode('utf8'))
 if re.fullmatch('[א-ת]',c):wh_chars.append({'letter':c,'point':base+min(byte_clocks[offset:offset+n]),'tokens':sorted(set(byte_tokens[offset:offset+n]))})
 offset+=n
ctc_chars=[]
for e in ctc['unreviewedGreedyCharacterEvidence']:
 if re.fullmatch('[א-ת]',e['label']):ctc_chars.append({'letter':e['label'],'point':e['analysisSampleSupport'][0]/16000,'frames':e['frames'],'sampleSupport':e['analysisSampleSupport'],'meanLogProbability':e['meanLogProbability']})

def discover(chars):
 s=''.join(c['letter']for c in chars);blocks={}
 for i in range(len(s)-k+1):
  g=ng.get(s[i:i+k],-1)
  if g<0:continue
  a=i;b=g;e=i+k;z=g+k
  while a>0 and b>0 and flat[b-1]!='\0'and s[a-1]==flat[b-1]:a-=1;b-=1
  while e<len(s)and z<len(flat)and flat[z]!='\0'and s[e]==flat[z]:e+=1;z+=1
  if e-a<rules['minimumExactBlockLetters']:continue
  first=bisect.bisect_left(starts,b);last=bisect.bisect_right(ends,z)
  full=[j for j in range(first,last)if spans[j][0]>=b and spans[j][1]<=z]
  if len(full)<rules['minimumFullyCoveredWords']:continue
  blocks[(a,e,b,z)]=full
 hits={}
 for (a,e,b,z),full in sorted(blocks.items()):
  for j in full:
   p=a+spans[j][0]-b;word=words[j];point=chars[p]['point'];entry={'wordId':word['id'],'hebrew':word['hebrew'],'point':point,'characterEvidence':chars[p],'rawLetterRange':[p,p+spans[j][1]-spans[j][0]],'exactContext':{'recognizerLetters':[a,e],'readerLetters':[b,z],'firstFullWordId':words[full[0]]['id'],'lastFullWordId':words[full[-1]]['id'],'letters':e-a,'fullWords':len(full),'someEightLetterContextUniqueAcrossWholeTorah':True}}
   key=(word['id'],point)
   if key not in hits or hits[key]['exactContext']['letters']<entry['exactContext']['letters']:hits[key]=entry
 return {'rawLetters':s,'blocks':len(blocks),'hits':list(hits.values())}
c=discover(ctc_chars);w=discover(wh_chars);wave,rate=sf.read(src['analysisFile'],dtype='float32');assert rate==16000 and wave.ndim==1 and len(wave)==src['analysisFrames'];byc={};byw={}
for v in c['hits']:byc.setdefault(v['wordId'],[]).append(v)
for v in w['hits']:byw.setdefault(v['wordId'],[]).append(v)
observations=[];counts={}
for word in bindings['words']:
 pairs=[]
 for ca in byc.get(word['id'],[]):
  for wa in byw.get(word['id'],[]):
   if abs(ca['point']-wa['point'])<=rules['maximumClockDisagreementSeconds']:pairs.append((ca,wa))
 reason=None;cue=None
 if not byc.get(word['id']):reason='no-complete-ctc-letter-anchor'
 elif not byw.get(word['id']):reason='no-complete-whisper-letter-anchor'
 elif not pairs:reason='source-model-clocks-disagree'
 elif len(pairs)!=1:reason='multiple-agreed-occurrences'
 else:
  ca,wa=pairs[0];point=ca['point'];lo=max(0,int((point-rules['pointActivityHalfWindowSeconds'])*rate));hi=min(len(wave),int((point+rules['pointActivityHalfWindowSeconds'])*rate));rms=float(np.sqrt(np.mean(np.square(wave[lo:hi],dtype=np.float64))));db=20*math.log10(rms)if rms else -float('inf')
  if not 0<=point<src['originalDuration']:reason='point-outside-native-source-clock'
  elif db<rules['minimumPointActivityRmsDbfs']:reason='insufficient-local-signal'
  else:cue={'point':point,'pointMeaning':'start of convolution support for the first exact CTC letter; not a heard word onset','context':{'start':max(0,point-rules['contextSecondsEachSide']),'end':min(src['originalDuration'],point+rules['contextSecondsEachSide'])},'ctc':ca,'whisper':wa,'clockDifferenceSeconds':abs(ca['point']-wa['point']),'localSignal':{'analysisSamples':[lo,hi],'rms':rms,'rmsDbfs':db,'speechOrPhonemeConfirmed':False},'wordStart':None,'wordEnd':None,'review':None}
 counts[reason or'agreed-listening-cue']=counts.get(reason or'agreed-listening-cue',0)+1;observations.append({'id':word['id'],'hebrew':word['hebrew'],'cue':cue,'withheldReason':reason,'approvedBoundary':None,'review':None})
# Apply the same context search to the known failed digital-silence output.
zero=read(P/'model-research/benchmark/zero-signal-control.json');zero_chars=[{'letter':x,'point':0}for x in letters(zero['rawModelText'])];negative=discover(zero_chars);assert not negative['hits']
out={'format':'tropetrain-private-observed-word-cues-v1','recipeSha256':sha(__file__),'rules':rules,'rulesSha256':sha(A/'predeclared-anchor-rules.json'),'recordId':src['recordId'],'source':{'id':src['recordId'],'bytes':src['originalBytes'],'sha1':src['originalSha1'],'sha256':src['originalSha256'],'duration':src['originalDuration']},'sourceClockFitted':False,'candidateCoverage':bindings['catalogCoverage'],'actualRecordingCoverage':None,'sourceEditionCompared':False,'inputs':{'ctc':{'file':str(ctc_path),'sha256':sha(ctc_path)},'whisper':{'file':str(wh_path),'sha256':sha(wh_path)},'bindings':{'file':str(bind_path),'sha256':sha(bind_path)},'readerIndexSha256':sha(reader_path),'analysisSha256':src['analysisSha256']},'models':[{'id':ctc['model'],'revision':ctc['modelRevision'],'license':'Apache-2.0'},{'id':wh['model'],'revision':identity['modelRevision'],'weightSha256':identity['weightSha256'],'license':'MIT-model-card'}],'wholeTorahSearchWords':79985,'ctcExactContextBlocks':c['blocks'],'whisperExactContextBlocks':w['blocks'],'ctcCandidateWords':len(set(x['wordId']for x in c['hits'])),'whisperCandidateWords':len(set(x['wordId']for x in w['hits'])),'counts':counts,'negativeControl':{'rawModelText':zero['rawModelText'],'directRecognizerControlFailed':True,'agreementCuesPassed':len(negative['hits'])},'words':observations,'acceptedWordTimes':None,'phonemes':None,'musicalNotes':None,'newVoice':None,'independentReview':None,'limits':'Sparse, unreviewed listening cues from two recognizers, unique literal whole-Torah context, fixed predeclared agreement/activity filters. Not word extents, heard onsets, musical/phonological/edition review or independent historical voices. Training overlap is possible. Canonical text/accents and original clocks remain unchanged.'}
(A/'observed-cues-analysis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');(A/'ctc-discovered-contexts.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');(A/'whisper-discovered-contexts.json').write_text(json.dumps(w,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'counts':counts,'ctcContexts':c['blocks'],'whisperContexts':w['blocks'],'zeroAgreementCues':len(negative['hits']),'closingVerse':[{k:v for k,v in o.items()if k!='cue'}|{'point':o['cue']['point']if o['cue']else None}for o in observations if o['id'].startswith('gen-28-4-')]},ensure_ascii=False),flush=True)
