This ZIP shares exact UTF8 file contents in files.json. manifest.json retains independent byte counts and SHA256 for every logical file. No source is removed or reserialized during restoration. NOTICE.txt states reuse rights.

Extract the ordinary ZIP support files with a ZIP tool. Then, using Python3 standard library only:
  python3 unpack.py /path/to/genesis-companion-sources.zip /tmp/tropetrain-companion-evidence

The destination must be new. It restores all43logicalfiles. To reproduce the text-only analyses against a complete TropeTrain source checkout or saved app folder (which includes the pinned older source pack and five unchanged Torah JSON books):
  TROPETRAIN_SOURCE_ROOT=/path/to/tropetrain python3 /tmp/tropetrain-companion-evidence/research-code/analyze-companions.py
  TROPETRAIN_SOURCE_ROOT=/path/to/tropetrain python3 /tmp/tropetrain-companion-evidence/research-code/discover-genesis.py

These commands read existing source observations, never run an audio decoder or play sound. They regenerate research/COMPANION-COVERAGE.json and research/GENESIS-CONTENT-DISCOVERY.json. Compare their bytes/SHA256 with the corresponding logical manifest records. Four source observations fail the retained candidate gate. No heard boundary, musical review or pronunciation voice is approved.
