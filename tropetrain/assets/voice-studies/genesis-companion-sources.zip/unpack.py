"""Restore exact UTF8 evidence files into a new directory; standard library only."""
from pathlib import Path
import hashlib,json,sys,zipfile
archive=Path(sys.argv[1]);target=Path(sys.argv[2]);assert not target.exists(),"Choose a new evidence directory."
with zipfile.ZipFile(archive)as z:
 manifest=json.loads(z.read('manifest.json'));raw=z.read(manifest['carrier']['file']);assert len(raw)==manifest['carrier']['bytes']and hashlib.sha256(raw).hexdigest()==manifest['carrier']['sha256'];shared=json.loads(raw);assert shared['format']=='tropetrain-lossless-utf8-files-v1'
 decoded={}
 for row in manifest['files']:
  name=row['file'];assert not Path(name).is_absolute()and'..'not in Path(name).parts;body=shared['files'][name].encode('utf-8');assert len(body)==row['bytes']and hashlib.sha256(body).hexdigest()==row['sha256'];decoded[name]=body
target.mkdir(parents=True)
for name,body in decoded.items():
 path=target/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(body)
print(f"Restored {len(decoded)} exact logical files; no audio/model execution.")
