"""Original source-only recognition. No expected text, voice generation or accepted times.

Read frozen earlier evidence without modifying those labs. All new artifacts live here.
"""
from pathlib import Path
import hashlib, json, math, os, shutil, time, itertools, resource
A=Path(__file__).resolve().parent;W=A.parents[2];R=A/'research';R.mkdir(exist_ok=True)
S=Path('/private/tmp/tropetrain-v99-worktree/tropetrain');OLD=W/'work/audits/acoustic-alignment-0.60';ORIGINALS=W/'work/audits/source-readers-0.98';MODEL=Path('/private/tmp/tropetrain-align-model-he53');RATE=16000

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()

def atomic_json(path,value):
 tmp=path.with_suffix(path.suffix+'.part');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');tmp.replace(path)

def prepare_sources():
 import numpy as np
 import soundfile as sf
 import scipy
 from scipy.signal import resample_poly
 catalog=json.loads((S/'docs/SOURCE-READERS.json').read_text());study=next(s for s in catalog['studies']if s['id']==catalog['featuredStudyId']);records={r['id']:r for r in catalog['recordings']};checked=json.loads((ORIGINALS/'research/featured-decoded.json').read_text())['records'];sources=[]
 for record_id in study['recordingIds']:
  r=records[record_id];pin=next(p for p in checked if p['sha256']==r['audio']['sha256']);original=ORIGINALS/pin['file'];assert original.stat().st_size==r['audio']['bytes']and sha(original)==pin['sha256'];signal,rate=sf.read(original,dtype='float32',always_2d=True);assert signal.shape[1]==r['nativeDecode']['channels']and np.isfinite(signal).all();assert all(np.array_equal(signal[:,0],signal[:,c])for c in range(signal.shape[1])),'Distinct channels require separate source inspection';assert len(signal)==r['nativeDecode']['frames']and rate==r['nativeDecode']['rate']
  divisor=math.gcd(rate,RATE);wave=resample_poly(signal[:,0],RATE//divisor,rate//divisor,window=('kaiser',5.0),padtype='constant').astype(np.float32);assert len(wave)==math.ceil(len(signal)*RATE/rate)and np.isfinite(wave).all();dest=R/(record_id+'-analysis.wav')
  if dest.exists():
   previous,pr=sf.read(dest,dtype='float32');assert pr==RATE and np.array_equal(previous,wave)
  else:sf.write(dest,wave,RATE,subtype='FLOAT')
  assert sha(original)==pin['sha256'];sources.append({'recordId':record_id,'sourceUrl':r['sourceUrl'],'originalFile':str(original),'originalSha256':pin['sha256'],'originalBytes':r['audio']['bytes'],'originalDecodedFrames':len(signal),'originalRate':rate,'originalChannels':signal.shape[1],'allChannelsBitIdentical':True,'analysisChannelIndex':0,'originalDuration':len(signal)/rate,'sourceMelodyLabel':r['sourceMelodyLabel'],'sourcePronunciationLabel':r['sourcePronunciationLabel'],'sourceLabelConflict':r.get('sourceLabelConflict'),'analysisFile':str(dest),'analysisSha256':sha(dest),'analysisFrames':len(wave),'analysisRate':RATE,'analysisDuration':len(wave)/RATE,'sourceClockOriginSeconds':0,'sourceClockFitted':False,'method':'Bit-identical dual-mono source channels verified; channel0 retained without mixing or discarded information. Untrimmed original decoded with soundfile '+sf.__version__+' / libsndfile '+sf.__libsndfile_version__+'; scipy '+scipy.__version__+' resample_poly, Kaiser5/constant padding, float32 analysis copy, origin0. No source mutation, amplitude clipping, duration fitting, phonetic substitution or sound output.','coverage':None,'wordTimes':None,'phonemes':None,'review':None})
 atomic_json(R/'source-audio.json',sources);return sources

def main():
 os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false')
 try:os.nice(10);priority='reduced by10'
 except PermissionError:priority='optional priority change denied; one CPU thread retained'
 import numpy as np
 import soundfile as sf
 import torch,transformers
 from transformers import Wav2Vec2FeatureExtractor,Wav2Vec2ForCTC
 sources=prepare_sources();pins=json.loads((OLD/'model-files.json').read_text());assert pins['model']=='imvladikon/wav2vec2-large-xlsr-53-hebrew'and pins['revision']=='3dd308dda70b20507a6920b459052635973ae3cd'
 for item in pins['files']:assert (MODEL/item['file']).stat().st_size==item['bytes']and sha(MODEL/item['file'])==item['sha256'],item['file']
 shutil.copy2(OLD/'model-files.json',R/'model-files.json');shutil.copy2(MODEL/'README.md',R/'model-card.md');shutil.copy2(OLD/'ctc_research.py',R/'prior-ctc-source.py')
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(0);torch.use_deterministic_algorithms(True)
 config=json.loads((MODEL/'config.json').read_text());vocabulary=json.loads((MODEL/'vocab.json').read_text());labels={v:k for k,v in vocabulary.items()};stride,support=1,1
 for kernel,step in zip(config['conv_kernel'],config['conv_stride']):support+=(kernel-1)*stride;stride*=step
 assert stride==320 and support==400 and config['pad_token_id']==vocabulary['[PAD]'];blank=vocabulary['[PAD]']
 feature=Wav2Vec2FeatureExtractor.from_pretrained(MODEL,local_files_only=True);model,info=Wav2Vec2ForCTC.from_pretrained(MODEL,local_files_only=True,use_safetensors=True,attn_implementation='eager',output_loading_info=True);assert not any(info.get(k)for k in['missing_keys','unexpected_keys','mismatched_keys','error_msgs']),info;model.eval().to('cpu')
 recipe=sha(__file__);shutil.copy2(__file__,R/('recipe-'+recipe+'.py'));index=[];start_time=time.monotonic();print(json.dumps({'modelLoaded':pins['model'],'revision':pins['revision'],'threads':1,'priority':priority,'device':'cpu','expectedTranscript':None,'sources':len(sources),'recipeSha256':recipe}),flush=True)
 for source in sources:
  directory=R/source['recordId'];directory.mkdir(exist_ok=True);assert sha(source['analysisFile'])==source['analysisSha256'];wave,rate=sf.read(source['analysisFile'],dtype='float32');assert rate==RATE and wave.ndim==1;tensor=feature(wave,sampling_rate=RATE,return_tensors='pt',return_attention_mask=False).input_values;frames=(len(wave)-support)//stride+1;pieces=[];chunks=[];began=time.monotonic()
  for first in range(0,frames,750):
   last=min(first+750,frames);left=max(0,first-100);right=min(frames,last+100);start=left*stride;end=(right-1)*stride+support;path=directory/(str(first).zfill(6)+'-'+str(last).zfill(6)+'.npz');meta=path.with_suffix('.json');identity={'recordId':source['recordId'],'originalSha256':source['originalSha256'],'analysisSha256':source['analysisSha256'],'modelRevision':pins['revision'],'recipeSha256':recipe,'firstFrame':first,'lastFrameExclusive':last,'inputSamples':[start,end],'globalStrideSamples':stride,'convolutionSupportSamples':support,'analysisRate':RATE,'expectedTranscript':None}
   if meta.exists():
    old=json.loads(meta.read_text());assert old['identity']==identity and old['complete']is True and sha(path)==old['sha256'];selected=np.load(path)['log_probs'];assert selected.shape==(last-first,len(labels))and np.isfinite(selected).all()
   else:
    with torch.inference_mode():
     logits=model(tensor[:,start:end]).logits[0];assert logits.shape==(right-left,config['vocab_size']);selected=torch.log_softmax(logits[first-left:last-left],dim=-1).cpu().numpy();assert selected.shape==(last-first,len(labels))and np.isfinite(selected).all()
    part=path.with_suffix('.npz.part')
    with part.open('wb')as f:np.savez_compressed(f,log_probs=selected)
    part.replace(path);atomic_json(meta,{'identity':identity,'file':path.name,'sha256':sha(path),'complete':True})
   pieces.append(selected);chunks.append({'file':str(path.relative_to(R)),'sha256':sha(path),'firstFrame':first,'lastFrameExclusive':last,'inputSamples':[start,end]});atomic_json(R/'working-index.json',{'recipeSha256':recipe,'currentRecord':source['recordId'],'retainedFrames':last,'totalFrames':frames,'completedSources':index,'complete':False});print(json.dumps({'recordId':source['recordId'],'retainedFrames':last,'frames':frames,'sourceSeconds':round(last*stride/RATE,2),'elapsedSeconds':round(time.monotonic()-began,2)}),flush=True)
  matrix=np.concatenate(pieces);assert matrix.shape==(frames,len(labels));path=matrix.argmax(axis=-1);characters=[];cursor=0
  for token,group in itertools.groupby(path.tolist()):
   length=sum(1 for _ in group);end=cursor+length
   if token!=blank:characters.append({'label':labels[token],'token':token,'frames':[cursor,end],'analysisSampleSupport':[cursor*stride,(end-1)*stride+support],'meanLogProbability':float(matrix[cursor:end,token].mean())})
   cursor=end
  assert cursor==frames;raw=''.join(' 'if c['label']=='|'else c['label']for c in characters)
  result={'schema':'tropetrain-source-only-ctc-observation-v1','recordId':source['recordId'],'sourceOriginalSha256':source['originalSha256'],'analysisSha256':source['analysisSha256'],'sourceMelodyLabel':source['sourceMelodyLabel'],'sourcePronunciationLabel':source['sourcePronunciationLabel'],'model':pins['model'],'modelRevision':pins['revision'],'modelLicense':pins['license'],'recipeSha256':recipe,'libraries':{'torch':torch.__version__,'transformers':transformers.__version__,'numpy':np.__version__,'soundfile':sf.__version__},'device':'cpu','threads':1,'priority':priority,'frameClock':{'analysisRate':RATE,'strideSamples':stride,'convolutionSupportSamples':support,'sourceOffsetSeconds':0,'durationFitting':False,'wordOrPhonemeBoundary':False},'featureNormalization':'Source-wide Wav2Vec2 feature normalization before chunking, identical to the earlier pinned research pipeline. Original file unchanged.','chunks':chunks,'frames':frames,'rawGreedyText':raw,'unreviewedGreedyCharacterEvidence':characters,'expectedTranscript':None,'languageModel':None,'recognitionPrompt':None,'sourceTextRewritten':False,'sourceEditionCompared':False,'coverage':None,'acceptedWordTimes':None,'syllableTimes':None,'phonemes':None,'musicalNotes':None,'review':None,'newVoice':None,'limits':'Unprompted modern speech-model hypothesis on chant. Neither orthography nor model frame supports certify pronunciation, physical word onsets, source edition, passage bounds or melodic tradition. No text supplied to recognition, transcript forced into its decoder or source time fitted.','elapsedSeconds':time.monotonic()-began,'maxResidentBytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'complete':True}
  assert sha(source['originalFile'])==source['originalSha256'];dest=directory/'unprompted-greedy.json';atomic_json(dest,result);index.append({'recordId':source['recordId'],'file':str(dest.relative_to(R)),'sha256':sha(dest),'frames':frames});atomic_json(R/'unprompted-index.json',{'model':pins['model'],'modelRevision':pins['revision'],'recipeSha256':recipe,'records':index,'complete':len(index)==len(sources),'review':None,'acceptedWordTimes':None});print(json.dumps({'completedSource':source['recordId'],'rawGreedyStart':raw[:500],'rawGreedyEnd':raw[-400:],'elapsedSeconds':round(time.monotonic()-began,2)},ensure_ascii=False),flush=True)
 print(json.dumps({'complete':True,'sources':len(index),'elapsedSeconds':round(time.monotonic()-start_time,2),'newAcceptedWordTimes':0,'newVoices':0}),flush=True)
if __name__=='__main__':main()
