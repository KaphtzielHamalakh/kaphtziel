"""Locate independent ASR strings across all Torah; preserve uncertainty and source text."""
from pathlib import Path
import json,gzip,hashlib,collections,bisect,difflib
A=Path(__file__).resolve().parent;R=A/'research';N=8;sha=lambda b:hashlib.sha256(b).hexdigest()
proof=json.loads((R/'reader-index-proof.json').read_text());packed=(R/'reader-index.json.gz').read_bytes();assert sha(packed)==proof['gzipSha256'];raw=gzip.decompress(packed);assert sha(raw)==proof['sha256'];reader=json.loads(raw);assert len(reader['words'])==79985 and len(reader['books'])==5
texts={};indices={};starts={};ends={};gram_index=collections.defaultdict(list)
for book in reader['books']:
 rows=reader['words'][slice(*book['words'])];pos=0;begins=[];stops=[]
 for w in rows:begins.append(pos);pos+=len(w['consonants']);stops.append(pos)
 text=''.join(w['consonants']for w in rows);assert len(text)==pos;texts[book['id']]=text;indices[book['id']]=rows;starts[book['id']]=begins;ends[book['id']]=stops
 for i in range(len(text)-N+1):gram_index[text[i:i+N]].append((book['id'],i))
results=[]
for p in sorted(R.glob('reader-original-*/unprompted-greedy.json')):
 obs=json.loads(p.read_text());assert obs['complete']and obs['expectedTranscript']is None and obs['recognitionPrompt']is None
 letters=''.join(c for c in obs['rawGreedyText']if'א'<=c<='ת');hits=[];scores=collections.defaultdict(set);unique_scores=collections.defaultdict(set)
 for i in range(len(letters)-N+1):
  gram=letters[i:i+N];locations=gram_index.get(gram,[])
  if len(locations)>16:continue
  for book,pos in locations:
   rows=indices[book];j=bisect.bisect_right(starts[book],pos)-1;w=rows[j];key=(book,w['chapter']);scores[key].add((gram,pos));
   if len(locations)==1:unique_scores[key].add((gram,pos))
   hits.append({'asrLetters':[i,i+N],'readerBook':book,'readerLetters':[pos,pos+N],'firstWordId':w['id'],'verse':w['verse'],'chapter':w['chapter'],'locationsAcrossAllTorah':len(locations)})
 ranked=sorted(scores,key=lambda k:(len(unique_scores[k]),len(scores[k])),reverse=True);top=[{'bookId':k[0],'chapter':k[1],'distinctAnchors':len(scores[k]),'uniqueAcrossAllTorah':len(unique_scores[k])}for k in ranked[:10]]
 detail=None
 if ranked:
  book,chapter=ranked[0];chapterrows=[w for w in indices[book]if w['chapter']==chapter];chaptertext=''.join(w['consonants']for w in chapterrows);cbegins=[];cursor=0
  for w in chapterrows:cbegins.append(cursor);cursor+=len(w['consonants'])
  matcher=difflib.SequenceMatcher(None,letters,chaptertext,autojunk=False);blocks=[{'asrLetters':[a,a+n],'readerLetters':[b,b+n],'length':n}for a,b,n in matcher.get_matching_blocks()if n];strong=[v for v in blocks if v['length']>=N];intervals=[]
  for v in strong:
   a,b=v['readerLetters'];first=chapterrows[bisect.bisect_right(cbegins,a)-1];last=chapterrows[bisect.bisect_right(cbegins,b-1)-1];intervals.append({'firstWordId':first['id'],'lastWordId':last['id'],'firstVerse':first['verse'],'lastVerse':last['verse'],'letters':v['length'],'asrLetters':v['asrLetters'],'readerLetters':v['readerLetters']})
  detail={'bookId':book,'chapter':chapter,'readerWords':len(chapterrows),'readerLetters':len(chaptertext),'asrLetters':len(letters),'orderedLiteralMatchLetters':sum(v['length']for v in blocks),'strongOrderedLiteralMatchLetters':sum(v['length']for v in strong),'strongMatches':intervals,'minimumStrongAnchorVerse':min((v['firstVerse']for v in intervals),default=None),'maximumStrongAnchorVerse':max((v['lastVerse']for v in intervals),default=None),'sourceRangeConfirmed':False,'acceptedWordTimes':None,'review':None}
 result={'schema':'tropetrain-private-source-content-anchors-v1','recordId':obs['recordId'],'sourceOriginalSha256':obs['sourceOriginalSha256'],'unpromptedObservationSha256':sha(p.read_bytes()),'readerIndexSha256':proof['sha256'],'rawRecognitionText':obs['rawGreedyText'],'asrConsonants':letters,'scope':{'readerBooks':5,'readerWords':79985,'ngramLetters':N,'frequentAnchorLocationsOmittedAbove':16},'topSourceChapters':top,'leadingCandidate':detail,'allExactAnchorHits':hits,'coverage':None,'acceptedWordTimes':None,'phonemes':None,'musicalReview':None,'review':None,'method':'Independent raw greedy recognition searched across the entire accepted Torah with exact8letter anchors. Analysis-only consonant filtering; original reader Hebrew/accents and recognition output remain unchanged. Chapter ranking by distinct anchors unique across allTorah, then all distinct anchors. Leading chapter comparison uses ordered literal difflib blocks; short accidental matches cannot define verse bounds. No source text or expected transcript was supplied to recognition.','limits':'Source content candidate evidence, not confirmed boundaries/edition/phonology/music or accepted time alignment. Unknown coverage stays null.'}
 dest=p.parent/'source-content-anchors.json';dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');results.append({'recordId':obs['recordId'],'file':str(dest.relative_to(R)),'sha256':sha(dest.read_bytes()),'topSourceChapters':top[:3],'strongAnchorVerses':[detail['minimumStrongAnchorVerse'],detail['maximumStrongAnchorVerse']]if detail else None});print(json.dumps(results[-1],ensure_ascii=False),flush=True)
(R/'source-content-discovery.json').write_text(json.dumps({'records':results,'completeObservationsFound':len(results),'sourceIndexWords':79985,'sourceIndexBooks':5,'coverage':None,'review':None},ensure_ascii=False,indent=2)+'\n')
