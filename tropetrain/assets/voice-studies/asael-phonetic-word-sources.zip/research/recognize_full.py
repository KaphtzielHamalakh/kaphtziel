"""Original reproducible source-phonetic research, not an approved chant transcription."""
from pathlib import Path
import hashlib,json,os,time,resource,math
ROOT=Path(__file__).resolve().parent;CACHE=Path('/private/tmp/tropetrain-phonetic-whisper-model');OUT=ROOT/'full';OUT.mkdir(exist_ok=True)
def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def main():
 os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false')
 import numpy as np
 import soundfile as sf
 import torch,transformers
 from transformers import WhisperForConditionalGeneration,WhisperFeatureExtractor,WhisperTokenizerFast
 recipe=digest(__file__);manifest=json.loads((ROOT/'model-files.json').read_text());assert manifest['complete']and manifest['revision']=='6f7c493615d163a99ed6ea09b2cb7241760d868b'
 for e in manifest['verified']:assert digest(CACHE/e['file'])==e['sha256'],e['file']
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(0);torch.use_deterministic_algorithms(True)
 features=WhisperFeatureExtractor(**json.loads((CACHE/'processor_config.json').read_text())['feature_extractor']);tokenizer=WhisperTokenizerFast.from_pretrained(str(CACHE),local_files_only=True)
 model,loading=WhisperForConditionalGeneration.from_pretrained(str(CACHE),local_files_only=True,use_safetensors=True,dtype=torch.float32,output_loading_info=True,attn_implementation='eager');assert not any(loading.get(k)for k in ['missing_keys','unexpected_keys','mismatched_keys','error_msgs']),loading;model.eval()
 print('Pinned phonetic model loaded/verified; CPU1thread, no speaker use. Recipe '+recipe,flush=True)
 sources=json.loads((ROOT.parent/'acoustic-alignment-0.60/source-audio.json').read_text());index=[]
 for source in sources:
  original=Path('/private/tmp/tropetrain-v60-release-source/tropetrain/assets/voice-studies/asael-2005')/('gen-1-1-to-2-3-'+('ashkenazic'if source['recordId'].endswith('ashkenazic')else'israeli')+'.oga')
  assert digest(original)==source['originalSha256']and digest(source['analysisFile'])==source['analysisSha256'];wave,rate=sf.read(source['analysisFile'],dtype='float32');assert rate==16000 and wave.ndim==1
  core=26*rate;context=2*rate;chunks=math.ceil(len(wave)/core)
  for i,start in enumerate(range(0,len(wave),core)):
   end=min(start+core,len(wave));left=max(0,start-context);right=min(end+context,len(wave));dest=OUT/(source['recordId']+'-'+str(i).zfill(3)+'.json')
   identity={'model':manifest['model'],'modelRevision':manifest['revision'],'sourceRecordId':source['recordId'],'sourceOriginalSha256':source['originalSha256'],'analysisWaveSha256':source['analysisSha256'],'recipeSha256':recipe,'chunkIndex':i,'coreSamples':[start,end],'inputSamples':[left,right],'analysisRate':rate}
   if dest.exists():
    old=json.loads(dest.read_text());assert all(old.get(k)==v for k,v in identity.items())and old.get('complete')is True,'Existing checkpoint identity differs: '+str(dest);index.append({'file':dest.name,'sha256':digest(dest),'sourceRecordId':source['recordId'],'chunkIndex':i});print('Reused exact completed '+dest.name,flush=True);continue
   begin=time.monotonic();clip=wave[left:right];inputs=features(clip,sampling_rate=rate,return_tensors='pt',return_attention_mask=True)
   with torch.inference_mode():
    encoder=model.model.encoder(inputs.input_features,output_attentions=False,return_dict=True)
    generated=model.generate(input_features=inputs.input_features,encoder_outputs=encoder,attention_mask=inputs.attention_mask,language='he',task='transcribe',return_timestamps=False,return_token_timestamps=True,num_frames=math.ceil(len(clip)/features.hop_length),max_new_tokens=444,do_sample=False,num_beams=1,return_dict_in_generate=True)
   ids=generated['sequences'][0].tolist();raw=tokenizer.decode(ids,skip_special_tokens=True,clean_up_tokenization_spaces=False);clock=generated['token_timestamps'][0].cpu().numpy().astype(float).tolist();assert len(clock)==len(ids)
   # Project complete Unicode characters to every source BPE token that contributed bytes.
   # Partial UTF8 decoder prefixes stay pending; no phoneme duration or subtoken interpolation.
   bindings=[];committed=0;pending=0
   for j in range(len(ids)):
    prefix=tokenizer.decode(ids[:j+1],skip_special_tokens=True,clean_up_tokenization_spaces=False);valid=0
    for a,b in zip(prefix,raw):
     if a!=b:break
     valid+=1
    assert valid>=committed,'Decoder prefix changed already committed characters.'
    assert not prefix[valid:]or set(prefix[valid:])=={'\ufffd'},'Non-UTF8 decoder rewrite; raw observation must remain unprojected.'
    for k in range(committed,valid):bindings.append({'textRange':[k,k+1],'text':raw[k],'tokenRange':[pending,j+1]})
    committed=valid
    if not prefix[valid:]:pending=j+1
   assert committed==len(raw)and ''.join(x['text']for x in bindings)==raw
   seconds=(right-left)/rate;clock_valid=all(math.isfinite(x)and 0<=x<=seconds+0.02 for x in clock)and all(a<=b+1e-7 for a,b in zip(clock,clock[1:]))
   result={'schema':'tropetrain-private-phonetic-source-window-v1',**identity,'modelLicense':manifest['license'],'sourceClock':{'coreSeconds':[start/rate,end/rate],'inputSeconds':[left/rate,right/rate],'sourceOffsetSeconds':left/rate,'codecOffsetGuessed':False},'rawModelOutput':raw,'generatedTokenIds':ids,'modelTokens':tokenizer.convert_ids_to_tokens(ids),'unreviewedRelativeTokenClock':clock,'tokenClockValidInInput':clock_valid,'unicodeCharacterTokenBindings':bindings,'tokenClockMethod':'Pinned Transformers cross-attention DTW with source-provided heads,20ms bins,7frame median, actual-frame crop. BPE locations are not phone or lexical boundaries. Exact26score/2scontext windows; no source mutation, transcript prompt, source-clock fitting or timestamp interpolation.','generationOutputKeys':list(generated),'promptedExpectedTranscript':None,'generation':{'sampling':False,'beams':1,'language':'he','task':'transcribe','maxNewTokens':444},'libraries':{'torch':torch.__version__,'transformers':transformers.__version__,'numpy':np.__version__,'soundfile':sf.__version__},'loadingInfo':loading,'device':'cpu','threads':torch.get_num_threads(),'weightComputeDtype':str(next(model.parameters()).dtype),'elapsedSeconds':time.monotonic()-begin,'maxResidentBytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'wordAlignment':None,'wordTimes':None,'syllableTimes':None,'phonemes':None,'review':None,'newVoice':None,'complete':True}
   temp=dest.with_suffix('.json.part');temp.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');temp.replace(dest);index.append({'file':dest.name,'sha256':digest(dest),'sourceRecordId':source['recordId'],'chunkIndex':i})
   (ROOT/'full-index-working.json').write_text(json.dumps({'recipeSha256':recipe,'completedWindows':index,'complete':False},indent=2)+'\n');print(json.dumps({'record':source['recordId'],'chunk':i+1,'total':chunks,'coreSeconds':[start/rate,end/rate],'rawModelOutput':raw,'validTokenClock':clock_valid,'elapsedSeconds':round(result['elapsedSeconds'],2)},ensure_ascii=False),flush=True)
   del generated,encoder,inputs
  assert digest(original)==source['originalSha256'];print('Original hash unchanged: '+source['recordId'],flush=True)
 (ROOT/'full-index.json').write_text(json.dumps({'model':manifest['model'],'modelRevision':manifest['revision'],'recipeSha256':recipe,'windows':index,'complete':True,'review':None},indent=2)+'\n');print('Full source phonetic research complete. All accepted fields remain null.',flush=True)
if __name__=='__main__':main()
