import{readFileSync,writeFileSync}from'node:fs';
import{PronunciationLibrary}from'/private/tmp/tropetrain-v60-release-source/tropetrain/pronunciation.js';
import{HISTORICAL_CATEGORY_INVENTORY as categories}from'/private/tmp/tropetrain-v60-release-source/tropetrain/historical-pronunciation-categories.js';
import{gunzipSync}from'node:zlib';
const packet=name=>JSON.parse(gunzipSync(readFileSync('/private/tmp/tropetrain-v60-release-source/tropetrain/data/pronunciation/'+name+'.json.gz')));
const input=JSON.parse(readFileSync(new URL('../acoustic-alignment-0.60/reader-bindings.json',import.meta.url))),lib=new PronunciationLibrary(packet('torah-display'),{underlay:packet('torah-underlay'),segments:packet('torah-segments')}),groups=[],seen=new Set();
for(const raw of input.words){
 const word={id:raw.id,sourceHebrew:raw.hebrew};const study=lib.study(word,'sephardic');if(!study)throw Error('Missing source group '+raw.id);
 if(seen.has(study.groupId))continue;seen.add(study.groupId);groups.push(study);
}
const output={schema:'tropetrain-private-source-pronunciation-bindings-v1',sourceCommit:categories.sourceCommit,categoryInputSha256:categories.inputSha256,readerWords:input.words,groups,categories:categories.catalog,license:'CC-BY-SA-4.0 source data; existing original projection keeps GPL3 computation evidence separate.',review:null};
writeFileSync(new URL('./source-pronunciation-bindings.json',import.meta.url),JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({words:input.words.length,groups:groups.length,first:groups[0].groupId,keys:Object.keys(groups[0]),multirow:groups.filter(g=>g.rows.length>1).map(g=>g.groupId),alternatives:groups.filter(g=>g.rows.some(r=>r.styles.sephardic.length>1||r.styles.sephardic.some(c=>c.units.some(u=>u.sourceSegments.variants.length>1)))).map(g=>g.groupId)}));
