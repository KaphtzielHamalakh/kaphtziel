"""Original source-word candidate bindings; every accepted acoustic field remains null."""
from pathlib import Path
import argparse,hashlib,json,math,time
from consonance import source_events,observed_atoms,all_optimal_matches
ROOT=Path(__file__).resolve().parent

def utf16slice(text,start,end):return text.encode('utf-16-le')[2*start:2*end].decode('utf-16-le')
def run(record,source,source_audio):
 files=sorted((ROOT/'full').glob(record+'-*.json'));assert len(files)==math.ceil(source_audio['analysisFrames']/(26*16000)),(record,len(files));windows=[json.loads(p.read_text())for p in files]
 assert [w['chunkIndex']for w in windows]==list(range(len(files)))
 assert windows[0]['coreSamples'][0]==0 and windows[-1]['coreSamples'][1]==source_audio['analysisFrames']
 assert all(a['coreSamples'][1]==b['coreSamples'][0]for a,b in zip(windows,windows[1:]))
 assert all(w['complete']and w['sourceRecordId']==record and w['sourceOriginalSha256']==source_audio['originalSha256']and w['analysisWaveSha256']==source_audio['analysisSha256']for w in windows)
 assert len({w['recipeSha256']for w in windows})==1
 observed,withheld,context_excluded=observed_atoms(windows);ctc=json.loads((ROOT.parent/'acoustic-alignment-0.60'/(record+'-word-support.json')).read_text());ctc_words={w['id']:w for w in ctc['words']};word_text={w['id']:w['hebrew']for w in source['readerWords']};results=[]
 for style in ['sephardic','ashkenazic']:
  begin=time.monotonic();events=source_events(source,style);expected=[{'class':atom,'eventIndex':i,'classPart':part}for i,e in enumerate(events)for part,atom in enumerate(e['classes'])];alignment=all_optimal_matches([x['class']for x in expected],[x['class']for x in observed]);words={w['id']:{'id':w['id'],'hebrew':w['hebrew'],'sourceEventIds':[e['eventId']for e in events if e['wordId']==w['id']],'candidateConsonants':[],'ambiguousConsonantReferences':0,'crossModelClockDisagreements':0,'approvedWordBoundary':None,'phonemes':None,'syllableTimes':None,'audioTimes':None,'review':None}for w in source['readerWords']};unique=ambiguous=unmatched=disagreement=0;event_map={e['eventId']:e for e in events}
  for row,obs in zip(alignment['matches'],observed):
   possibilities=[events[expected[i]['eventIndex']]for i in row['expectedCandidates']];owners={e['wordId']for e in possibilities}
   if row['unmatchedInSomeOptimalPath']or len(owners)!=1:
    if possibilities:
     ambiguous+=1
     for owner in owners:words[owner]['ambiguousConsonantReferences']+=1
    else:unmatched+=1
    continue
   owner=next(iter(owners));ctc_word=ctc_words[owner];assert ctc_word['hebrew']==word_text[owner];support=ctc_word['modelSupport'];context=[max(0,support['start']-1),min(source_audio['analysisDuration'],support['end']+1)];lo,hi=obs['modelLocationBins']
   if lo<context[0]-1e-7 or hi>context[1]+1e-7:
    disagreement+=1;words[owner]['crossModelClockDisagreements']+=1;continue
   candidate_events=list(dict.fromkeys(e['eventId']for e in possibilities));window=windows[obs['window']];raw=window['rawModelOutput'];a,b=obs['textRange'];range16=[len(raw[:a].encode('utf-16-le'))//2,len(raw[:b].encode('utf-16-le'))//2];assert utf16slice(raw,*range16)==obs['text']
   candidate={'modelWindow':obs['window'],'modelCharacterRange':range16,'modelCoordinateUnit':'UTF-16','modelGlyph':obs['text'],'modelLocationBins':obs['modelLocationBins'],'analysisClass':obs['class'],'modelClassPart':obs['classPart'],'sourceEventCandidates':candidate_events,'sourceClassPart':expected[row['uniqueExpectedIndex']]['classPart']if row['uniqueExpectedIndex']is not None else None,'letterBindingUnique':len(candidate_events)==1,'allOptimalPathsSameWord':True,'withinOriginalWordAuditionContext':True,'phonemes':None,'audioTimes':None,'review':None}
   words[owner]['candidateConsonants'].append(candidate);unique+=1
  for word in words.values():
   word['sourceEvents']=[event_map[i]for i in word.pop('sourceEventIds')]
   for event in word['sourceEvents']:
    for binding in event['sourceClusters']:
     for r in binding['readerClusterRanges']or[]:assert utf16slice(word_text[r['readerWordId']],r['start'],r['end'])==r['text'],'Marked Hebrew cluster changed.'
  result={'schema':'tropetrain-phonetic-consonant-word-study-v1','revision':1,'sourceRecordId':record,'sourceOriginalSha256':source_audio['originalSha256'],'sourceTranscriptionComparisonStyle':style,'pronunciationSourceCommit':source['sourceCommit'],'pronunciationCategoryInputSha256':source['categoryInputSha256'],'model':windows[0]['model'],'modelRevision':windows[0]['modelRevision'],'inferenceRecipeSha256':windows[0]['recipeSha256'],'modelWindows':[{'index':w['chunkIndex'],'rawModelOutput':w['rawModelOutput'],'sourceClock':w['sourceClock']}for w in windows],'words':list(words.values()),'diagnostics':{'expectedSourceEvents':len(events),'expectedConsonantAtoms':len(expected),'observedConsonantAtoms':len(observed),'minimumConsonantEditDistance':alignment['distance'],'sameWordInEveryOptimalPath':unique,'ambiguousReferencesWithheld':ambiguous,'unmatchedObservations':unmatched,'crossModelClockDisagreementsWithheld':disagreement,'modelCoreBoundaryObservationsWithheld':len(withheld),'modelContextAtomsExcluded':context_excluded,'wordsWithCandidates':sum(bool(w['candidateConsonants'])for w in words.values()),'elapsedSeconds':time.monotonic()-begin},'algorithm':alignment['method'],'modelWindowBoundaryGaps':withheld,'acceptedWordTimes':None,'syllableAlignment':None,'phonemes':None,'musicalNotes':None,'independentReview':None,'newVoice':None,'limits':'Unprompted speech-model output on chant, with errors. Abstract consonant classes compare r/ʁ/ɾ and x/χ without selecting an allophone; tsadi compares T+S without deciding an affricate boundary or duration. Both existing MAM text styles are separate comparison hypotheses, not a pronunciation identified for the source performer. Model whitespace does not assign Hebrew word ownership. Only exact class matches with one word owner in every minimum-edit path, within the separate original CTC audition context, are displayed. All accepted phones, vowels, word/syllable/note timing and review fields remain null. No confidence threshold or source-clock correction creates acceptance.'}
  dest=ROOT/(record+'-'+style+'-consonance.json');dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');results.append({'record':record,'style':style,**result['diagnostics'],'file':dest.name,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()});print(json.dumps(results[-1]),flush=True)
 return results

def main():
 p=argparse.ArgumentParser();p.add_argument('--record');args=p.parse_args();source=json.loads((ROOT/'source-pronunciation-bindings.json').read_text());sources=json.loads((ROOT.parent/'acoustic-alignment-0.60/source-audio.json').read_text());results=[]
 for s in sources:
  if args.record and s['recordId']!=args.record:continue
  results+=run(s['recordId'],source,s)
 (ROOT/('consonance-summary'+('-'+args.record if args.record else'')+'.json')).write_text(json.dumps(results,indent=2)+'\n')
if __name__=='__main__':main()
