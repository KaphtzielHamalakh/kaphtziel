from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parent
CACHE=Path('/private/tmp/tropetrain-phonetic-whisper-model');CACHE.mkdir(exist_ok=True)
meta=json.loads((ROOT/'notmax123--whisper-heb-ipa.json').read_text());revision=meta['sha'];assert revision=='6f7c493615d163a99ed6ea09b2cb7241760d868b' and meta['cardData']['license']=='apache-2.0'
files={x['path']:x for x in json.loads((ROOT/'model-tree.json').read_text())if x['type']=='file'}
wanted=['README.md','config.json','generation_config.json','processor_config.json','tokenizer_config.json','tokenizer.json','model.safetensors'];verified=[]
for name in wanted:
 entry=files[name];dest=CACHE/name
 if not dest.exists():
  part=dest.with_suffix(dest.suffix+'.part');url='https://huggingface.co/notmax123/whisper-heb-ipa/resolve/'+revision+'/'+name
  if part.exists():raise RuntimeError('Partial file exists; inspect its originating process before any retry: '+str(part))
  subprocess.run(['curl','--fail','--silent','--show-error','--location','--max-time','1200','--output',str(part),url],check=True);part.rename(dest)
 raw=dest.read_bytes();assert len(raw)==entry['size'],name
 if entry.get('lfs'):expected=entry['lfs']['oid'];actual=hashlib.sha256(raw).hexdigest()
 else:expected=entry['oid'];actual=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
 assert actual==expected,(name,actual,expected)
 verified.append({'file':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'sourceGitOrLfsHash':expected})
 (ROOT/'model-files.json').write_text(json.dumps({'model':meta['modelId'],'revision':revision,'license':'Apache-2.0 explicit pinned model card','cache':str(CACHE),'verified':verified,'complete':len(verified)==len(wanted)},indent=2)+'\n')
 print('Verified '+name+' '+str(len(raw))+' bytes.',flush=True)
print('All pinned phonetic model inputs verified.',flush=True)
