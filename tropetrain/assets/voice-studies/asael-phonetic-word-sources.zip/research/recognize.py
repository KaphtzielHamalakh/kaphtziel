"""Original bounded, unprompted phonetic ASR research. No timing/phonology approval."""
from pathlib import Path
import argparse,hashlib,json,os,time,resource
ROOT=Path(__file__).resolve().parent
CACHE=Path('/private/tmp/tropetrain-phonetic-whisper-model')
def sha256(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--seconds',type=float,default=15);args=parser.parse_args();assert 0<args.seconds<=30
 os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1';os.environ['TOKENIZERS_PARALLELISM']='false'
 import numpy as np
 import soundfile as sf
 import torch,transformers
 from transformers import WhisperForConditionalGeneration,WhisperFeatureExtractor,WhisperTokenizerFast
 manifest=json.loads((ROOT/'model-files.json').read_text());assert manifest['complete']and manifest['revision']=='6f7c493615d163a99ed6ea09b2cb7241760d868b'
 for entry in manifest['verified']:assert sha256(CACHE/entry['file'])==entry['sha256'],entry['file']
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(0);torch.use_deterministic_algorithms(True)
 start=time.monotonic();print('All model hashes verified. Loading local safetensors on CPU,1thread,float32.',flush=True)
 features=WhisperFeatureExtractor(**json.loads((CACHE/'processor_config.json').read_text())['feature_extractor'])
 tokenizer=WhisperTokenizerFast.from_pretrained(str(CACHE),local_files_only=True)
 model,loading=WhisperForConditionalGeneration.from_pretrained(str(CACHE),local_files_only=True,use_safetensors=True,torch_dtype=torch.float32,output_loading_info=True,attn_implementation='eager')
 assert not any(loading.get(k)for k in ['missing_keys','unexpected_keys','mismatched_keys','error_msgs']),loading
 model.eval();print('Model loaded in '+str(round(time.monotonic()-start,2))+'s.',flush=True)
 sources=json.loads((ROOT.parent/'acoustic-alignment-0.60/source-audio.json').read_text());results=[]
 for source in sources:
  original=Path('/private/tmp/tropetrain-v60-release-source/tropetrain/assets/voice-studies/asael-2005')/('gen-1-1-to-2-3-'+('ashkenazic'if source['recordId'].endswith('ashkenazic')else'israeli')+'.oga')
  assert sha256(original)==source['originalSha256']and sha256(source['analysisFile'])==source['analysisSha256']
  wave,rate=sf.read(source['analysisFile'],dtype='float32');assert rate==16000 and wave.ndim==1
  count=int(round(args.seconds*rate));assert count<=len(wave);clip=wave[:count];begin=time.monotonic()
  inputs=features(clip,sampling_rate=rate,return_tensors='pt',return_attention_mask=True)
  print('Recognizing '+source['recordId']+' source[0,'+str(args.seconds)+')seconds, unprompted.',flush=True)
  with torch.inference_mode():
   encoder=model.model.encoder(inputs.input_features,output_attentions=False,return_dict=True)
   generated=model.generate(input_features=inputs.input_features,encoder_outputs=encoder,attention_mask=inputs.attention_mask,language='he',task='transcribe',return_timestamps=False,return_token_timestamps=True,num_frames=int(np.ceil(count/features.hop_length)),max_new_tokens=444,do_sample=False,num_beams=1,return_dict_in_generate=True)
   score_items=generated.get('scores')
   scores=model.compute_transition_scores(generated['sequences'],score_items,normalize_logits=True)[0].cpu().numpy().astype(float).tolist()if score_items else None
  ids=generated['sequences'][0].tolist();raw=tokenizer.decode(ids,skip_special_tokens=True);full=tokenizer.convert_ids_to_tokens(ids)
  clock=generated['token_timestamps'][0].cpu().numpy().astype(float).tolist()
  observation={'sourceRecordId':source['recordId'],'rawModelOutput':raw,'generatedTokenIds':ids,'tokenClock':clock,'generationOutputKeys':list(generated),'review':None}
  (ROOT/(source['recordId']+'-preview-observation.json')).write_text(json.dumps(observation,ensure_ascii=False,indent=2)+'\n')
  print('Observed raw output: '+raw,flush=True)
  result={'schema':'tropetrain-private-phonetic-asr-research-v1','model':manifest['model'],'modelRevision':manifest['revision'],'modelLicense':manifest['license'],'sourceRecordId':source['recordId'],'sourceOriginalSha256':source['originalSha256'],'analysisWaveSha256':source['analysisSha256'],'sourceClock':{'startSample':0,'endSampleExclusive':count,'rate':rate,'startSeconds':0,'endSeconds':count/rate,'timingMethod':'Exact unchanged analysis-copy start; no source-clock offset, trimming or duration fitting.'},'rawModelOutput':raw,'generatedTokenIds':ids,'modelTokens':full,'unreviewedTokenClock':clock,'tokenClockMethod':'Pinned Transformers cross-attention DTW with source-provided alignment heads,20ms bins,7frame median filter, cropped to actual input features. Model BPE tokens are not phonemes or word boundaries. Encoder computed separately without retained encoder-attention matrices; no timestamp-based audio trimming.','generatedTokenLogProbabilities':scores,'promptedExpectedTranscript':None,'sampling':False,'beams':1,'device':'cpu','threads':torch.get_num_threads(),'weightComputeDtype':str(next(model.parameters()).dtype),'libraries':{'torch':torch.__version__,'transformers':transformers.__version__,'numpy':np.__version__,'soundfile':sf.__version__},'loadingInfo':loading,'elapsedSeconds':time.monotonic()-begin,'maxResidentBytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'wordAlignment':None,'wordTimes':None,'syllableTimes':None,'phonemes':None,'review':None,'newVoice':None,'limits':'Modern speech-model hypothesis on chant, not a verified phonetic transcription, dialect realization, source-edition correspondence or timed word/phoneme. Original Hebrew text and accents are not inputs or outputs of a text-replacement operation.'}
  assert sha256(original)==source['originalSha256'];dest=ROOT/(source['recordId']+'-preview.json');dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');results.append(result);print(json.dumps({'record':source['recordId'],'sourceSeconds':count/rate,'rawModelOutput':raw,'elapsedSeconds':round(result['elapsedSeconds'],2)},ensure_ascii=False),flush=True)
 (ROOT/'preview-summary.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print('Bounded phonetic research complete; accepted fields remain null.',flush=True)
if __name__=='__main__':main()
