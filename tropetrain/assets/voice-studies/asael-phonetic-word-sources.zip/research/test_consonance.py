import itertools,unittest
from consonance import all_optimal_matches,source_classes,observed_classes

def oracle(expected,observed):
 n,m=len(expected),len(observed);best=None;paths=[]
 def visit(i,j,cost,edges):
  nonlocal best,paths
  if best is not None and cost>best:return
  if i==n and j==m:
   if best is None or cost<best:best=cost;paths=[]
   if cost==best:paths.append(edges)
   return
  if i<n:visit(i+1,j,cost+1,edges)
  if j<m:visit(i,j+1,cost+1,edges+[(j,None)])
  if i<n and j<m:visit(i+1,j+1,cost+int(expected[i]!=observed[j]),edges+[(j,i if expected[i]==observed[j]else None)])
 visit(0,0,0,[]);rows=[]
 for j in range(m):
  options={dict(path)[j]for path in paths};rows.append((sorted(x for x in options if x is not None),None in options))
 return best,rows

class ConsonanceTests(unittest.TestCase):
 def test_every_optimal_path_against_independent_exhaustive_enumeration(self):
  cases=[tuple(x)for n in range(4)for x in itertools.product('ab',repeat=n)]
  for e in cases:
   for o in cases:
    distance,rows=oracle(e,o);got=all_optimal_matches(e,o);self.assertEqual(got['distance'],distance)
    self.assertEqual([(r['expectedCandidates'],r['unmatchedInSomeOptimalPath'])for r in got['matches']],rows)
 def test_repeated_consonants_do_not_get_arbitrary_letter_assignment(self):
  r=all_optimal_matches(['R','R'],['R'])['matches'][0];self.assertEqual(r['expectedCandidates'],[0,1]);self.assertIsNone(r['uniqueExpectedIndex'])
 def test_exact_match_is_withheld_when_an_optimal_path_can_omit_it(self):
  r=all_optimal_matches(['A'],['A','A'])['matches'];self.assertTrue(all(x['unmatchedInSomeOptimalPath']and x['uniqueExpectedIndex']is None for x in r))
 def test_source_text_styles_change_tav_only_at_the_consonant_comparison_layer(self):
  c={'id':'TAV_0DAG','kind':'consonant'};self.assertEqual(source_classes(c,'sephardic'),['T']);self.assertEqual(source_classes(c,'ashkenazic'),['S']);self.assertEqual(c,{'id':'TAV_0DAG','kind':'consonant'})
 def test_model_allophones_are_abstract_classes_not_a_phone_replacement(self):
  self.assertEqual(observed_classes('ʁ'),['R']);self.assertEqual(observed_classes('r'),['R']);self.assertEqual(observed_classes('χ'),['X']);self.assertEqual(observed_classes('ʔ'),['G']);self.assertEqual(observed_classes('ɔ'),[]);self.assertEqual(observed_classes('֣'),[]);self.assertEqual(observed_classes('Q'),['OTHER_U0051'])
 def test_affricate_atoms_keep_ambiguous_tav_samekh_and_tsadi_possible(self):
  self.assertEqual(source_classes({'id':'TSADI_0DAG','kind':'consonant'},'sephardic'),['T','S']);self.assertEqual(observed_classes('ʦ'),['T','S']);self.assertEqual(observed_classes('t')+observed_classes('s'),['T','S'])
 def test_unknown_is_not_silence_and_empty_sequences_have_explicit_edits(self):
  self.assertRaises(ValueError,source_classes,{'id':'NO_SOURCE','kind':'consonant'},'sephardic');self.assertRaises(ValueError,all_optimal_matches,[''],['A']);self.assertEqual(all_optimal_matches([],['A'])['distance'],1);self.assertTrue(all_optimal_matches([],['A'])['matches'][0]['unmatchedInSomeOptimalPath'])
if __name__=='__main__':unittest.main()
